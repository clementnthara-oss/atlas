export type OutcomeKey = 'revenue' | 'efficiency' | 'trust' | 'growth';

export interface Metric {
  name: string;
  before: string | null;
  after: string | null;
  change: string | null;
  unit: string | null;
  period: string | null;
  source: string | null;
  verified: boolean;
}

export interface FlowStep {
  label: string;
  detail: string;
  input?: string;
  decision?: string;
  action?: string;
  output?: string;
}

export interface Service {
  slug: string;
  name: string;
  short: string;
  description: string;
  accent: string;
  outcomes: OutcomeKey[];
  capabilities: string[];
  metricCategories: string[];
  flow: string[];
}

export type CaseStatus = 'Concept' | 'Prototype' | 'In progress' | 'Private beta' | 'Live';

export interface CaseStudy {
  slug: string;
  client: string;
  industry: string;
  status: CaseStatus;
  published: boolean;
  summary: string;
  problem: string;
  opportunity: string;
  discovery: string;
  strategy: string;
  design: string;
  engineering: string;
  ai: string;
  automation: string;
  outcome: string;
  reflection: string;
  services: string[];
  technology: string[];
  metrics: Metric[];
  accent: string;
}

export interface StudioProduct {
  name: string;
  status: 'Research' | 'Prototype' | 'Building' | 'Private beta' | 'Live';
  problem: string;
  market: string;
  product: string;
  technology: string;
  learning: string;
  accent: string;
}