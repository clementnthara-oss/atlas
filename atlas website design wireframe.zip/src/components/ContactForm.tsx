import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { CheckIcon, LoaderIcon } from 'lucide-react';

const goals = [
'Grow revenue',
'Reduce operational work',
'Improve customer experience',
'Build a new product',
'Introduce AI',
'Automate a process',
'Modernize existing systems',
'I\u2019m not sure yet'];


interface FormState {
  goals: string[];
  today: string;
  constraint: string;
  success: string;
  tried: string;
  name: string;
  company: string;
  email: string;
  phone: string;
}

const empty: FormState = {
  goals: [],
  today: '',
  constraint: '',
  success: '',
  tried: '',
  name: '',
  company: '',
  email: '',
  phone: ''
};

type Errors = Partial<Record<keyof FormState, string>>;

export function ContactForm() {
  const [form, setForm] = useState<FormState>(empty);
  const [errors, setErrors] = useState<Errors>({});
  const [status, setStatus] = useState<'idle' | 'submitting' | 'done'>('idle');

  const set = <K extends keyof FormState,>(key: K, value: FormState[K]) =>
  setForm((f) => ({ ...f, [key]: value }));

  const toggleGoal = (goal: string) =>
  setForm((f) => ({
    ...f,
    goals: f.goals.includes(goal) ? f.goals.filter((g) => g !== goal) : [...f.goals, goal]
  }));

  const validate = (): boolean => {
    const next: Errors = {};
    if (form.goals.length === 0) next.goals = 'Pick at least one — “I’m not sure yet” is a valid answer.';
    if (!form.today.trim()) next.today = 'Tell us what happens today, even roughly.';
    if (!form.name.trim()) next.name = 'We need a name to address you by.';
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) next.email = 'Enter a valid email address.';
    setErrors(next);
    return Object.keys(next).length === 0;
  };

  const onSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    window.dispatchEvent(new CustomEvent('aig:form-submit-attempt'));
    if (!validate()) return;
    setStatus('submitting');
    window.setTimeout(() => {
      setStatus('done');
      window.dispatchEvent(new CustomEvent('aig:form-complete', { detail: { goals: form.goals } }));
    }, 900);
  };

  if (status === 'done') {
    return (
      <motion.div
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
        role="status"
        className="rounded-feature border border-ink/10 bg-white p-9 sm:p-12">
        
        <span className="flex h-11 w-11 items-center justify-center rounded-full bg-neon">
          <CheckIcon className="h-5 w-5 text-ink" aria-hidden="true" />
        </span>
        <h2 className="mt-6 text-h2 font-semibold">Thank you — that&rsquo;s enough to start.</h2>
        <p className="mt-4 max-w-lg text-bodylg text-ink-muted">
          You&rsquo;ll hear back from the person who will actually work on this, not an account manager. We
          read what you wrote before the call, so the first conversation starts somewhere useful.
        </p>
        <dl className="mt-8 grid gap-4 sm:grid-cols-2">
          <div className="rounded-card border border-ink/10 bg-base p-4">
            <dt className="label text-ink-faint">What you told us</dt>
            <dd className="mt-2 text-[13px] text-ink">{form.goals.join(' · ')}</dd>
          </div>
          <div className="rounded-card border border-ink/10 bg-base p-4">
            <dt className="label text-ink-faint">Next</dt>
            <dd className="mt-2 text-[13px] text-ink">A reply, then a call. No quote template.</dd>
          </div>
        </dl>
      </motion.div>);

  }

  const field =
  'w-full rounded-control border border-ink/15 bg-white px-4 py-3 text-[14px] text-ink placeholder:text-ink-faint transition-colors focus:border-atlas';

  return (
    <form onSubmit={onSubmit} noValidate className="space-y-10">
      <fieldset>
        <legend className="text-h3 font-semibold">What are you trying to accomplish?</legend>
        <p className="mt-2 text-sm text-ink-muted">Choose as many as apply.</p>
        <div className="mt-5 flex flex-wrap gap-2">
          {goals.map((g) => {
            const on = form.goals.includes(g);
            return (
              <button
                key={g}
                type="button"
                onClick={() => toggleGoal(g)}
                aria-pressed={on}
                className={`rounded-control border px-4 py-2.5 text-[13px] transition-all duration-200 ${
                on ?
                'border-ink bg-ink text-white' :
                'border-ink/15 bg-white text-ink-muted hover:border-ink/40 hover:text-ink'}`
                }>
                
                {on && <span className="mr-2 text-neon">✓</span>}
                {g}
              </button>);

          })}
        </div>
        {errors.goals &&
        <p className="mt-3 text-[13px] text-magenta" role="alert">
            {errors.goals}
          </p>
        }
      </fieldset>

      <div className="grid gap-6">
        {[
        { key: 'today' as const, label: 'What\u2019s happening today?', hint: 'How the process runs right now, including the messy parts.', required: true },
        { key: 'constraint' as const, label: 'What\u2019s the biggest constraint?', hint: 'Time, budget, people, systems, data — whatever is actually in the way.', required: false },
        { key: 'success' as const, label: 'What would success look like?', hint: 'If this went well, what would be different in six months?', required: false },
        { key: 'tried' as const, label: 'What have you already tried?', hint: 'Optional. Useful for avoiding a repeat.', required: false }].
        map((f) =>
        <div key={f.key}>
            <label htmlFor={f.key} className="block text-[15px] font-medium text-ink">
              {f.label}
              {!f.required && <span className="ml-2 text-[12px] font-normal text-ink-faint">Optional</span>}
            </label>
            <p className="mt-1.5 text-[13px] text-ink-muted">{f.hint}</p>
            <textarea
            id={f.key}
            rows={3}
            value={form[f.key]}
            onChange={(e) => set(f.key, e.target.value)}
            aria-invalid={Boolean(errors[f.key])}
            aria-describedby={errors[f.key] ? `${f.key}-error` : undefined}
            className={`${field} mt-3 resize-y`} />
          
            {errors[f.key] &&
          <p id={`${f.key}-error`} className="mt-2 text-[13px] text-magenta" role="alert">
                {errors[f.key]}
              </p>
          }
          </div>
        )}
      </div>

      <fieldset className="border-t border-ink/10 pt-8">
        <legend className="sr-only">Your details</legend>
        <div className="grid gap-5 sm:grid-cols-2">
          {[
          { key: 'name' as const, label: 'Name', type: 'text', required: true, autoComplete: 'name' },
          { key: 'company' as const, label: 'Company', type: 'text', required: false, autoComplete: 'organization' },
          { key: 'email' as const, label: 'Email', type: 'email', required: true, autoComplete: 'email' },
          { key: 'phone' as const, label: 'Phone', type: 'tel', required: false, autoComplete: 'tel' }].
          map((f) =>
          <div key={f.key}>
              <label htmlFor={f.key} className="block text-[13px] font-medium text-ink">
                {f.label}
                {!f.required && <span className="ml-2 font-normal text-ink-faint">Optional</span>}
              </label>
              <input
              id={f.key}
              type={f.type}
              autoComplete={f.autoComplete}
              value={form[f.key]}
              onChange={(e) => set(f.key, e.target.value)}
              aria-invalid={Boolean(errors[f.key])}
              aria-describedby={errors[f.key] ? `${f.key}-error` : undefined}
              className={`${field} mt-2`} />
            
              {errors[f.key] &&
            <p id={`${f.key}-error`} className="mt-2 text-[13px] text-magenta" role="alert">
                  {errors[f.key]}
                </p>
            }
            </div>
          )}
        </div>
      </fieldset>

      <div className="flex flex-wrap items-center gap-4">
        <button
          type="submit"
          disabled={status === 'submitting'}
          className="inline-flex h-13 items-center justify-center gap-2 rounded-control bg-ink px-7 text-[15px] font-medium text-white transition-colors hover:bg-atlas disabled:opacity-70">
          
          {status === 'submitting' && <LoaderIcon className="h-4 w-4 animate-spin" aria-hidden="true" />}
          {status === 'submitting' ? 'Sending' : 'Book a Call'}
        </button>
        <p className="text-[12px] text-ink-faint">
          No quote templates. No sales sequence. One human reply.
        </p>
      </div>
    </form>);

}