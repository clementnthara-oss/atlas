import React, { useEffect, useState } from 'react';
import { motion, useReducedMotion } from 'framer-motion';
import { CTAButton } from '../ui/CTAButton';
import { AtlasSystem } from '../system/AtlasSystem';

export function Hero() {
  const reduce = useReducedMotion();
  const [active, setActive] = useState(0);

  useEffect(() => {
    if (reduce) return;
    const id = window.setInterval(() => setActive((v) => (v + 1) % 4), 2600);
    return () => window.clearInterval(id);
  }, [reduce]);

  const words = ['We build intelligent systems for', 'businesses that want to move further.'];

  return (
    <section className="relative w-full overflow-hidden bg-base" aria-labelledby="hero-title">
      <div className="pointer-events-none absolute inset-0 grid-lines opacity-40" aria-hidden="true" />
      <div
        className="pointer-events-none absolute -right-40 -top-40 h-[560px] w-[560px] rounded-full opacity-[0.18] blur-3xl"
        style={{ background: 'radial-gradient(circle, #2457FF 0%, transparent 65%)' }}
        aria-hidden="true" />
      

      <div className="relative mx-auto grid max-w-site gap-12 px-5 pb-20 pt-16 sm:px-8 md:pb-30 md:pt-24 lg:grid-cols-[1.05fr_1fr] lg:items-center lg:gap-16">
        <div>
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
            className="inline-flex items-center gap-2 rounded-full border border-ink/12 bg-white px-3 py-1.5">
            
            <span className="relative flex h-1.5 w-1.5">
              <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-atlas opacity-60" />
              <span className="relative inline-flex h-1.5 w-1.5 rounded-full bg-atlas" />
            </span>
            <span className="label text-ink-muted">AI agency &middot; Client Services + Product Studio</span>
          </motion.div>

          <h1 id="hero-title" className="mt-7 text-display font-semibold text-ink">
            {words.map((line, i) =>
            <motion.span
              key={line}
              className="block"
              initial={reduce ? { opacity: 0 } : { opacity: 0, y: 24 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7, delay: 0.06 + i * 0.09, ease: [0.22, 1, 0.36, 1] }}>
              
                {i === 1 ?
              <>
                    businesses that want to{' '}
                    <span className="relative inline-block">
                      move further.
                      <motion.span
                    className="absolute -bottom-1 left-0 h-[6px] w-full rounded-full bg-neon"
                    initial={{ scaleX: 0, originX: 0 }}
                    animate={{ scaleX: 1 }}
                    transition={{ duration: 0.7, delay: 0.7, ease: [0.22, 1, 0.36, 1] }} />
                  
                    </span>
                  </> :

              line
              }
              </motion.span>
            )}
          </h1>

          <motion.p
            initial={{ opacity: 0, y: 14 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.28, ease: [0.22, 1, 0.36, 1] }}
            className="mt-7 max-w-xl text-bodylg text-ink-muted">
            
            From websites and SaaS platforms to AI agents, automation, CRMs and business systems — we turn
            real business problems into technology that creates measurable value.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 14 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.38, ease: [0.22, 1, 0.36, 1] }}
            className="mt-9 flex flex-wrap items-center gap-3">
            
            <CTAButton to="/contact" size="lg">
              Book a Call
            </CTAButton>
            <CTAButton to="/work" size="lg" variant="secondary">
              See What&rsquo;s Possible
            </CTAButton>
          </motion.div>

          <motion.dl
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.6, delay: 0.5 }}
            className="mt-14 grid max-w-lg grid-cols-2 gap-x-8 gap-y-6 border-t border-ink/10 pt-8 sm:grid-cols-4">
            
            {[
            ['Understand', 'the business'],
            ['Diagnose', 'the friction'],
            ['Build', 'what changes it'],
            ['Evolve', 'after launch']].
            map(([term, desc], i) =>
            <div key={term}>
                <dt className="label text-ink" style={{ color: i === active ? '#2457FF' : undefined }}>
                  {term}
                </dt>
                <dd className="mt-1.5 text-sm text-ink-muted">{desc}</dd>
              </div>
            )}
          </motion.dl>
        </div>

        <motion.div
          initial={{ opacity: 0, scale: 0.97 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.9, delay: 0.15, ease: [0.22, 1, 0.36, 1] }}
          className="relative">
          
          <AtlasSystem active={active} onSelect={setActive} />
        </motion.div>
      </div>
    </section>);

}