import React, { useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { method } from '../../data/site';
import { SectionLabel } from '../ui/Section';

export function Method() {
  const [active, setActive] = useState(0);
  const stage = method[active];

  return (
    <section className="w-full border-y border-ink/10 bg-white py-20 md:py-30" aria-labelledby="method-title">
      <div className="mx-auto max-w-site px-5 sm:px-8">
        <SectionLabel accent={stage.accent}>The AIG method</SectionLabel>
        <div className="mt-6 flex flex-wrap items-end justify-between gap-6">
          <h2 id="method-title" className="max-w-2xl text-h1 font-semibold">
            A process you can watch happening.
          </h2>
          <p className="max-w-sm text-sm text-ink-muted">
            Regular check-ins throughout, so nothing about the result is a surprise at delivery.
          </p>
        </div>

        <div className="mt-14">
          <ol className="grid gap-2 sm:grid-cols-3 lg:grid-cols-6">
            {method.map((m, i) => {
              const isActive = i === active;
              const isPast = i < active;
              return (
                <li key={m.stage}>
                  <button
                    type="button"
                    onClick={() => setActive(i)}
                    aria-pressed={isActive}
                    className="group w-full text-left">
                    
                    <span
                      className="block h-1 w-full rounded-full transition-colors duration-300"
                      style={{ background: isActive || isPast ? m.accent : 'rgba(8,9,11,0.1)' }} />
                    
                    <span className="mt-3 block label text-ink-faint">{String(i + 1).padStart(2, '0')}</span>
                    <span
                      className={`mt-1 block text-[15px] font-semibold transition-colors ${
                      isActive ? 'text-ink' : 'text-ink-faint group-hover:text-ink-muted'}`
                      }>
                      
                      {m.stage}
                    </span>
                  </button>
                </li>);

            })}
          </ol>

          <AnimatePresence mode="wait">
            <motion.div
              key={stage.stage}
              initial={{ opacity: 0, y: 14 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.35, ease: [0.22, 1, 0.36, 1] }}
              className="mt-10 grid gap-8 rounded-feature border border-ink/10 bg-base p-6 sm:p-10 lg:grid-cols-[1.2fr_1fr_1fr]">
              
              <div>
                <span className="label" style={{ color: stage.accent }}>
                  Stage {String(active + 1).padStart(2, '0')}
                </span>
                <h3 className="mt-3 text-h2 font-semibold">{stage.stage}</h3>
                <p className="mt-4 max-w-md text-bodylg text-ink-muted">{stage.question}</p>
              </div>
              <div>
                <span className="label text-ink-faint">Inputs</span>
                <ul className="mt-4 space-y-2">
                  {stage.inputs.map((x) =>
                  <li key={x} className="flex items-center gap-2.5 text-[13px] text-ink-muted">
                      <span className="h-px w-3 bg-ink/25" aria-hidden="true" />
                      {x}
                    </li>
                  )}
                </ul>
              </div>
              <div>
                <span className="label text-ink-faint">Outputs</span>
                <ul className="mt-4 space-y-2">
                  {stage.outputs.map((x) =>
                  <li key={x} className="flex items-center gap-2.5 text-[13px] text-ink">
                      <span className="h-1.5 w-1.5 rounded-full" style={{ background: stage.accent }} aria-hidden="true" />
                      {x}
                    </li>
                  )}
                </ul>
              </div>
            </motion.div>
          </AnimatePresence>
        </div>
      </div>
    </section>);

}