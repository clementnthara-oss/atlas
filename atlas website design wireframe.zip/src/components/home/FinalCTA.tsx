import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { CTAButton } from '../ui/CTAButton';

export function FinalCTA() {
  return (
    <section
      className="relative w-full overflow-hidden py-30 md:py-38"
      style={{
        background:
        'linear-gradient(165deg, #08090B 0%, #0B1B4D 32%, #2457FF 62%, #FF3CAC 88%, #FAFAF7 100%)'
      }}
      aria-labelledby="final-cta-title">
      
      <div className="pointer-events-none absolute inset-0 dot-grid opacity-20" aria-hidden="true" />
      <div className="relative mx-auto max-w-site px-5 text-center sm:px-8">
        <motion.h2
          id="final-cta-title"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-80px' }}
          transition={{ duration: 0.7, ease: [0.22, 1, 0.36, 1] }}
          className="mx-auto max-w-4xl text-display font-semibold text-white">
          
          There&rsquo;s probably a better way to run this.
        </motion.h2>
        <motion.p
          initial={{ opacity: 0, y: 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.1, ease: [0.22, 1, 0.36, 1] }}
          className="mt-6 text-h3 font-medium text-white/70">
          
          Let&rsquo;s find it.
        </motion.p>
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.18 }}
          className="mt-11 flex flex-wrap justify-center gap-3">
          
          <CTAButton to="/contact" size="lg" variant="onDark">
            Book a Call
          </CTAButton>
          <Link
            to="/work"
            className="group inline-flex h-13 items-center justify-center gap-2 rounded-control border border-white/40 px-7 text-[15px] font-medium text-white transition-colors hover:border-white hover:bg-white/10">
            
            See What&rsquo;s Possible
          </Link>
        </motion.div>
      </div>
    </section>);

}