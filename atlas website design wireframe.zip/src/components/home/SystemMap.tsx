import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { SectionLabel } from '../ui/Section';

type Goal = 'More Revenue' | 'Less Manual Work' | 'Better Customer Experience' | 'Scale';

interface MapNode {
  id: string;
  x: number;
  y: number;
  goals: Goal[];
}

const nodes: MapNode[] = [
{ id: 'Customer', x: 8, y: 50, goals: ['More Revenue', 'Better Customer Experience'] },
{ id: 'Brand', x: 22, y: 18, goals: ['More Revenue', 'Better Customer Experience'] },
{ id: 'Marketing', x: 22, y: 82, goals: ['More Revenue'] },
{ id: 'Website', x: 36, y: 50, goals: ['More Revenue', 'Better Customer Experience'] },
{ id: 'Lead', x: 50, y: 22, goals: ['More Revenue', 'Less Manual Work'] },
{ id: 'Sales', x: 50, y: 78, goals: ['More Revenue'] },
{ id: 'CRM', x: 63, y: 50, goals: ['Less Manual Work', 'Scale', 'Better Customer Experience'] },
{ id: 'Operations', x: 76, y: 20, goals: ['Less Manual Work', 'Scale'] },
{ id: 'Finance', x: 76, y: 80, goals: ['Scale'] },
{ id: 'AI', x: 88, y: 34, goals: ['Less Manual Work', 'Scale', 'Better Customer Experience'] },
{ id: 'Automation', x: 88, y: 66, goals: ['Less Manual Work', 'Scale'] },
{ id: 'Analytics', x: 63, y: 92, goals: ['Scale', 'More Revenue'] },
{ id: 'Insights', x: 36, y: 92, goals: ['Scale'] }];


const edges: [string, string][] = [
['Customer', 'Brand'],
['Customer', 'Marketing'],
['Brand', 'Website'],
['Marketing', 'Website'],
['Website', 'Lead'],
['Website', 'Sales'],
['Lead', 'CRM'],
['Sales', 'CRM'],
['CRM', 'Operations'],
['CRM', 'Finance'],
['Operations', 'AI'],
['Finance', 'Automation'],
['AI', 'Automation'],
['CRM', 'Analytics'],
['Analytics', 'Insights'],
['Insights', 'Website']];


const goals: {label: Goal;accent: string;}[] = [
{ label: 'More Revenue', accent: '#2457FF' },
{ label: 'Less Manual Work', accent: '#B7FF3C' },
{ label: 'Better Customer Experience', accent: '#FF3CAC' },
{ label: 'Scale', accent: '#FF8A3D' }];


export function SystemMap() {
  const [goal, setGoal] = useState<Goal>('More Revenue');
  const accent = goals.find((g) => g.label === goal)!.accent;
  const lit = new Set(nodes.filter((n) => n.goals.includes(goal)).map((n) => n.id));

  return (
    <section className="w-full border-y border-ink/10 bg-white py-20 md:py-30" aria-labelledby="map-title">
      <div className="mx-auto max-w-site px-5 sm:px-8">
        <div className="grid gap-8 lg:grid-cols-[1fr_auto] lg:items-end">
          <div>
            <SectionLabel accent={accent}>Business systems</SectionLabel>
            <h2 id="map-title" className="mt-6 max-w-2xl text-h1 font-semibold">
              Your business is a system.
              <span className="block text-ink-faint">We build the connective tissue.</span>
            </h2>
          </div>
          <p className="max-w-sm text-sm text-ink-muted">
            Choose what you are trying to change. The parts of the system that carry that outcome light up.
          </p>
        </div>

        <div className="mt-10 flex flex-wrap gap-2" role="group" aria-label="Business goal">
          {goals.map((g) => {
            const isActive = g.label === goal;
            return (
              <button
                key={g.label}
                type="button"
                onClick={() => setGoal(g.label)}
                aria-pressed={isActive}
                className="rounded-control border px-4 py-2.5 text-[13px] font-medium transition-all duration-200"
                style={{
                  borderColor: isActive ? g.accent : 'rgba(8,9,11,0.14)',
                  background: isActive ? g.accent : '#FFFFFF',
                  color: isActive ? g.accent === '#B7FF3C' || g.accent === '#FF8A3D' ? '#08090B' : '#FFFFFF' : '#5A5D66'
                }}>
                
                {g.label}
              </button>);

          })}
        </div>

        <div className="mt-10 overflow-hidden rounded-feature border border-ink/10 bg-base">
          {/* Desktop / tablet map */}
          <div className="relative hidden aspect-[16/9] w-full dot-grid-light sm:block">
            <svg viewBox="0 0 100 100" preserveAspectRatio="none" className="absolute inset-0 h-full w-full" aria-hidden="true">
              {edges.map(([a, b]) => {
                const na = nodes.find((n) => n.id === a)!;
                const nb = nodes.find((n) => n.id === b)!;
                const on = lit.has(a) && lit.has(b);
                return (
                  <line
                    key={`${a}-${b}`}
                    x1={na.x}
                    y1={na.y}
                    x2={nb.x}
                    y2={nb.y}
                    stroke={on ? accent : 'rgba(8,9,11,0.12)'}
                    strokeWidth={on ? 0.45 : 0.25}
                    vectorEffect="non-scaling-stroke"
                    className={on ? 'dash-flow' : ''}
                    style={{ transition: 'stroke 400ms' }} />);


              })}
            </svg>

            {nodes.map((n) => {
              const on = lit.has(n.id);
              return (
                <motion.div
                  key={n.id}
                  className="absolute -translate-x-1/2 -translate-y-1/2"
                  style={{ left: `${n.x}%`, top: `${n.y}%` }}
                  animate={{ scale: on ? 1 : 0.94 }}
                  transition={{ duration: 0.4, ease: [0.22, 1, 0.36, 1] }}>
                  
                  <span
                    className="flex items-center gap-2 whitespace-nowrap rounded-full border px-3 py-1.5 text-[11px] font-medium transition-colors duration-400"
                    style={{
                      borderColor: on ? accent : 'rgba(8,9,11,0.12)',
                      background: on ? accent : '#FFFFFF',
                      color: on ? accent === '#B7FF3C' || accent === '#FF8A3D' ? '#08090B' : '#FFFFFF' : '#8A8D96'
                    }}>
                    
                    {on && <span className="h-1.5 w-1.5 rounded-full bg-current opacity-70" aria-hidden="true" />}
                    {n.id}
                  </span>
                </motion.div>);

            })}
          </div>

          {/* Mobile: vertical list, no microscopic diagram */}
          <ul className="divide-y divide-ink/8 sm:hidden">
            {nodes.map((n) => {
              const on = lit.has(n.id);
              return (
                <li key={n.id} className="flex items-center justify-between px-5 py-3.5">
                  <span className={`text-sm ${on ? 'font-medium text-ink' : 'text-ink-faint'}`}>{n.id}</span>
                  <span
                    className="rounded-full px-2 py-0.5 text-[10px] font-medium"
                    style={{
                      background: on ? accent : 'rgba(8,9,11,0.05)',
                      color: on ? accent === '#B7FF3C' || accent === '#FF8A3D' ? '#08090B' : '#FFFFFF' : '#8A8D96'
                    }}>
                    
                    {on ? 'Active' : 'Idle'}
                  </span>
                </li>);

            })}
          </ul>
        </div>

        <p className="mt-5 text-[12px] text-ink-faint">
          Illustrative system map. Every engagement starts by mapping the real one.
        </p>
      </div>
    </section>);

}