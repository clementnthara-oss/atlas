import React, { useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { SectionLabel } from '../ui/Section';

interface Node {
  label: string;
  input: string;
  decision: string;
  action: string;
  output: string;
}

const nodes: Node[] = [
{
  label: 'Customer message',
  input: 'Email, form or chat message arrives',
  decision: 'Is this an enquiry, a support request, or noise?',
  action: 'Normalise into a single structured intake record',
  output: 'One record, one state, one owner'
},
{
  label: 'Understand intent',
  input: 'Raw message plus prior history',
  decision: 'What is this person actually asking for?',
  action: 'Extract intent, urgency and entities',
  output: 'Structured intent with confidence score'
},
{
  label: 'Qualify enquiry',
  input: 'Intent plus the business\u2019s own criteria',
  decision: 'Does this meet the definition of a good enquiry?',
  action: 'Score against criteria; route anything ambiguous to a person',
  output: 'Qualified / needs review / not a fit'
},
{
  label: 'Check CRM',
  input: 'Contact and company identifiers',
  decision: 'Do we already know this person?',
  action: 'Match, deduplicate and enrich',
  output: 'Correct record, no duplicates'
},
{
  label: 'Create record',
  input: 'Qualified enquiry',
  decision: 'Which pipeline and stage does this belong to?',
  action: 'Write to CRM with source, intent and context attached',
  output: 'Auditable record of what happened and why'
},
{
  label: 'Notify team',
  input: 'New or updated record',
  decision: 'Who needs to know, and how urgently?',
  action: 'Route to the right person with the context already summarised',
  output: 'A person picks up a decision, not an inbox'
},
{
  label: 'Schedule follow-up',
  input: 'Record state and timing rules',
  decision: 'What happens if nobody replies?',
  action: 'Queue follow-ups and escalations',
  output: 'Nothing depends on memory'
},
{
  label: 'Measure outcome',
  input: 'Record lifecycle events',
  decision: 'Did the system make good calls?',
  action: 'Evaluate decisions against real outcomes',
  output: 'Evidence, and the next improvement'
}];


export function AIWorkflow() {
  const [selected, setSelected] = useState(1);
  const node = nodes[selected];

  return (
    <section className="relative w-full overflow-hidden bg-ink py-20 md:py-30" aria-labelledby="ai-title">
      <div
        className="pointer-events-none absolute inset-0"
        style={{ background: 'radial-gradient(70% 50% at 20% 0%, rgba(183,255,60,0.18) 0%, transparent 65%)' }}
        aria-hidden="true" />
      
      <div className="relative mx-auto max-w-site px-5 sm:px-8">
        <SectionLabel tone="dark" accent="#B7FF3C">
          AI systems
        </SectionLabel>
        <div className="mt-6 flex flex-wrap items-end justify-between gap-6">
          <h2 id="ai-title" className="text-h1 font-semibold text-white">
            AI that does work.
          </h2>
          <p className="max-w-md text-sm text-white/55">
            Select any step to see what goes in, what gets decided, what happens, and what it leaves behind.
            Illustrative workflow — no client data.
          </p>
        </div>

        <div className="mt-14 grid gap-8 lg:grid-cols-[1fr_minmax(0,420px)] lg:gap-14">
          <ol className="relative space-y-2">
            {nodes.map((n, i) => {
              const isActive = i === selected;
              return (
                <li key={n.label}>
                  <button
                    type="button"
                    onClick={() => setSelected(i)}
                    aria-pressed={isActive}
                    className="group flex w-full items-center gap-4 rounded-control border px-4 py-3.5 text-left transition-all duration-300 ease-atlas"
                    style={{
                      borderColor: isActive ? '#B7FF3C' : 'rgba(255,255,255,0.1)',
                      background: isActive ? 'rgba(183,255,60,0.08)' : 'rgba(255,255,255,0.02)'
                    }}>
                    
                    <span
                      className="label w-6 shrink-0"
                      style={{ color: isActive ? '#B7FF3C' : 'rgba(255,255,255,0.3)' }}>
                      
                      {String(i + 1).padStart(2, '0')}
                    </span>
                    <span className={`flex-1 text-[15px] ${isActive ? 'text-white' : 'text-white/60'}`}>
                      {n.label}
                    </span>
                    <span
                      className="h-2 w-2 shrink-0 rounded-full transition-all duration-300"
                      style={{
                        background: isActive ? '#B7FF3C' : 'rgba(255,255,255,0.18)',
                        boxShadow: isActive ? '0 0 0 5px rgba(183,255,60,0.15)' : 'none'
                      }}
                      aria-hidden="true" />
                    
                  </button>
                  {i < nodes.length - 1 &&
                  <span
                    className="ml-8 block h-3 w-px"
                    style={{ background: i < selected ? '#B7FF3C' : 'rgba(255,255,255,0.14)' }}
                    aria-hidden="true" />

                  }
                </li>);

            })}
          </ol>

          <div className="lg:sticky lg:top-24 lg:self-start">
            <AnimatePresence mode="wait">
              <motion.div
                key={node.label}
                initial={{ opacity: 0, y: 14 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                transition={{ duration: 0.32, ease: [0.22, 1, 0.36, 1] }}
                className="rounded-feature border border-white/12 bg-white/[0.04] p-6 sm:p-8">
                
                <span className="label text-neon">Step {String(selected + 1).padStart(2, '0')}</span>
                <h3 className="mt-3 text-h3 font-semibold text-white">{node.label}</h3>
                <dl className="mt-7 space-y-5">
                  {[
                  ['Input', node.input],
                  ['Decision', node.decision],
                  ['Action', node.action],
                  ['Output', node.output]].
                  map(([term, desc], i) =>
                  <div key={term} className="border-l pl-4" style={{ borderColor: ['#25D9FF', '#B7FF3C', '#FF8A3D', '#FF3CAC'][i] }}>
                      <dt className="label text-white/40">{term}</dt>
                      <dd className="mt-1.5 text-[14px] leading-relaxed text-white/80">{desc}</dd>
                    </div>
                  )}
                </dl>
              </motion.div>
            </AnimatePresence>
          </div>
        </div>
      </div>
    </section>);

}