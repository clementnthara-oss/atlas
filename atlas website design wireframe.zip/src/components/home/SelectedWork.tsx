import React from 'react';
import { caseStudies } from '../../data/caseStudies';
import { SectionLabel } from '../ui/Section';
import { Reveal } from '../ui/Reveal';
import { CaseStudyCard } from '../CaseStudyCard';
import { CTAButton } from '../ui/CTAButton';

export function SelectedWork() {
  return (
    <section className="w-full bg-base py-20 md:py-30" aria-labelledby="work-title">
      <div className="mx-auto max-w-site px-5 sm:px-8">
        <div className="flex flex-wrap items-end justify-between gap-6">
          <div>
            <SectionLabel>Selected work</SectionLabel>
            <Reveal>
              <h2 id="work-title" className="mt-6 max-w-2xl text-h1 font-semibold">
                How an engagement actually runs.
              </h2>
            </Reveal>
          </div>
          <CTAButton to="/work" variant="secondary">
            See What&rsquo;s Possible
          </CTAButton>
        </div>

        <div className="mt-6 max-w-2xl rounded-card border border-ink/10 bg-white p-5">
          <p className="text-[13px] leading-relaxed text-ink-muted">
            <span className="font-medium text-ink">A note on honesty.</span> Client case studies are published
            only with the client&rsquo;s permission and with measured numbers attached. Until then, these are
            documented engagement patterns — the real structure of the work, with nothing invented.
          </p>
        </div>

        <div className="mt-10 space-y-4">
          {caseStudies.map((study, i) =>
          <CaseStudyCard key={study.slug} study={study} index={i} />
          )}
        </div>
      </div>
    </section>);

}