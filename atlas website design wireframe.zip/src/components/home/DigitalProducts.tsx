import React, { useRef, useState } from 'react';
import { motion, useScroll, useTransform } from 'framer-motion';
import { SectionLabel } from '../ui/Section';
import { Reveal } from '../ui/Reveal';
import { BrowserFrame } from '../system/BrowserFrame';

const surfaces = ['Website', 'Web app', 'Dashboard', 'Customer portal'] as const;

export function DigitalProducts() {
  const ref = useRef<HTMLDivElement>(null);
  const [surface, setSurface] = useState<(typeof surfaces)[number]>('Website');
  const { scrollYProgress } = useScroll({ target: ref, offset: ['start end', 'end start'] });
  const y1 = useTransform(scrollYProgress, [0, 1], [40, -40]);
  const y2 = useTransform(scrollYProgress, [0, 1], [80, -70]);

  return (
    <section ref={ref} className="w-full bg-base py-20 md:py-30" aria-labelledby="products-title">
      <div className="mx-auto max-w-site px-5 sm:px-8">
        <div className="grid gap-10 lg:grid-cols-[1fr_1.25fr] lg:items-center lg:gap-16">
          <div>
            <SectionLabel>Digital products</SectionLabel>
            <Reveal>
              <h2 id="products-title" className="mt-6 text-h1 font-semibold">
                Digital experiences designed to move people.
              </h2>
            </Reveal>
            <Reveal delay={0.06}>
              <p className="mt-6 max-w-lg text-bodylg text-ink-muted">
                Websites, web apps, SaaS platforms and portals — built around the decision a visitor is
                actually making, then measured on whether they made it.
              </p>
            </Reveal>

            <Reveal delay={0.1}>
              <div className="mt-9 flex flex-wrap gap-2" role="tablist" aria-label="Product surfaces">
                {surfaces.map((s) =>
                <button
                  key={s}
                  role="tab"
                  aria-selected={surface === s}
                  onClick={() => setSurface(s)}
                  className={`rounded-control border px-3.5 py-2 text-[13px] transition-all duration-200 ${
                  surface === s ?
                  'border-ink bg-ink text-white' :
                  'border-ink/15 bg-white text-ink-muted hover:border-ink/40 hover:text-ink'}`
                  }>
                  
                    {s}
                  </button>
                )}
              </div>
            </Reveal>

            <Reveal delay={0.14}>
              <div className="mt-10 border-t border-ink/10 pt-8">
                <span className="label text-ink-faint">What gets measured</span>
                <dl className="mt-4 grid grid-cols-2 gap-x-6 gap-y-4 sm:grid-cols-3">
                  {['Conversion', 'Engagement', 'Task completion', 'Performance', 'Accessibility'].map((m) =>
                  <div key={m}>
                      <dt className="text-[13px] font-medium text-ink">{m}</dt>
                      <dd className="mt-0.5 text-[11px] text-ink-faint">Not yet measured</dd>
                    </div>
                  )}
                </dl>
              </div>
            </Reveal>
          </div>

          <div className="relative">
            <motion.div style={{ y: y1 }}>
              <BrowserFrame surface={surface} />
            </motion.div>
            <motion.div
              style={{ y: y2 }}
              className="absolute -bottom-10 -left-4 hidden w-56 rounded-card border border-ink/10 bg-white p-4 shadow-[0_20px_50px_-30px_rgba(8,9,11,0.5)] sm:block">
              
              <span className="label text-ink-faint">Flow</span>
              <ol className="mt-3 space-y-2">
                {['Brand', 'Experience', 'Action', 'Result'].map((step, i) =>
                <li key={step} className="flex items-center gap-2.5 text-[12px] text-ink">
                    <span
                    className="h-1.5 w-1.5 rounded-full"
                    style={{ background: ['#2457FF', '#25D9FF', '#B7FF3C', '#FF8A3D'][i] }} />
                  
                    {step}
                  </li>
                )}
              </ol>
            </motion.div>
          </div>
        </div>
      </div>
    </section>);

}