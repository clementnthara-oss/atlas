import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { outcomes } from '../../data/outcomes';
import { SectionLabel } from '../ui/Section';
import { Reveal } from '../ui/Reveal';
import { OutcomeGlyph } from '../system/OutcomeGlyph';

export function Outcomes() {
  const [open, setOpen] = useState<number>(0);

  return (
    <section className="w-full border-y border-ink/10 bg-white py-20 md:py-30" aria-labelledby="outcomes-title">
      <div className="mx-auto max-w-site px-5 sm:px-8">
        <SectionLabel>What you are actually buying</SectionLabel>
        <Reveal>
          <h2 id="outcomes-title" className="mt-6 max-w-4xl text-h1 font-semibold">
            You don&rsquo;t need more software.
            <span className="block text-ink-faint">You need software that changes something.</span>
          </h2>
        </Reveal>

        <div className="mt-14 grid gap-px overflow-hidden rounded-feature border border-ink/10 bg-ink/10 md:grid-cols-4">
          {outcomes.map((o, i) => {
            const isOpen = open === i;
            return (
              <button
                key={o.key}
                type="button"
                onMouseEnter={() => setOpen(i)}
                onFocus={() => setOpen(i)}
                onClick={() => setOpen(i)}
                aria-pressed={isOpen}
                className="group relative min-h-[320px] overflow-hidden bg-white p-6 text-left transition-colors duration-500 ease-atlas md:min-h-[420px]"
                style={{ background: isOpen ? o.accent : '#FFFFFF' }}>
                
                <div className="relative flex h-full flex-col">
                  <div className="flex items-baseline justify-between">
                    <span
                      className="label transition-colors duration-500"
                      style={{ color: isOpen ? o.ink : '#8A8D96' }}>
                      
                      0{i + 1}
                    </span>
                    <span
                      className="h-2 w-2 rounded-full transition-colors duration-500"
                      style={{ background: isOpen ? o.ink : o.accent }} />
                    
                  </div>

                  <h3
                    className="mt-6 text-h3 font-semibold transition-colors duration-500"
                    style={{ color: isOpen ? o.ink : '#08090B' }}>
                    
                    {o.title}
                  </h3>
                  <p
                    className="mt-3 text-sm leading-relaxed transition-colors duration-500"
                    style={{ color: isOpen ? o.ink === '#FFFFFF' ? 'rgba(255,255,255,0.8)' : 'rgba(8,9,11,0.72)' : '#5A5D66' }}>
                    
                    {o.line}
                  </p>

                  <div className="my-6 flex-1">
                    <OutcomeGlyph outcome={o.key} active={isOpen} accent={o.accent} ink={o.ink} />
                  </div>

                  <motion.ul
                    animate={{ opacity: isOpen ? 1 : 0.45 }}
                    className="space-y-1.5"
                    style={{ color: isOpen ? o.ink : '#8A8D96' }}>
                    
                    {o.points.slice(0, 3).map((p) =>
                    <li key={p} className="text-[12px]">
                        {p}
                      </li>
                    )}
                  </motion.ul>
                </div>
              </button>);

          })}
        </div>
      </div>
    </section>);

}