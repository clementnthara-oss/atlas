import React, { useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { ArrowUpRightIcon } from 'lucide-react';
import { services } from '../../data/services';
import { SectionLabel } from '../ui/Section';
import { FlowStrip } from '../system/FlowStrip';

export function ServiceEcosystem() {
  const [active, setActive] = useState(0);
  const service = services[active];

  return (
    <section
      className="relative w-full overflow-hidden py-20 transition-colors duration-700 ease-atlas md:py-30"
      style={{ background: '#08090B' }}
      aria-labelledby="services-title">
      
      <motion.div
        className="pointer-events-none absolute inset-0"
        animate={{ opacity: 1 }}
        style={{
          background: `radial-gradient(80% 60% at 78% 30%, ${service.accent}33 0%, transparent 70%)`,
          transition: 'background 700ms cubic-bezier(0.22,1,0.36,1)'
        }}
        aria-hidden="true" />
      
      <div className="pointer-events-none absolute inset-0 dot-grid opacity-30" aria-hidden="true" />

      <div className="relative mx-auto max-w-site px-5 sm:px-8">
        <SectionLabel tone="dark" accent={service.accent}>
          What we actually build
        </SectionLabel>
        <h2 id="services-title" className="mt-6 max-w-3xl text-h1 font-semibold text-white">
          Six capabilities. One system that grows with the business.
        </h2>

        <div className="mt-14 grid gap-10 lg:grid-cols-[minmax(0,340px)_1fr] lg:gap-16">
          <ul className="flex gap-2 overflow-x-auto pb-2 no-scrollbar lg:block lg:space-y-1 lg:overflow-visible lg:pb-0">
            {services.map((s, i) => {
              const isActive = i === active;
              return (
                <li key={s.slug} className="shrink-0 lg:shrink">
                  <button
                    type="button"
                    onMouseEnter={() => setActive(i)}
                    onFocus={() => setActive(i)}
                    onClick={() => setActive(i)}
                    aria-pressed={isActive}
                    className="group flex w-full items-center gap-3 whitespace-nowrap rounded-control border px-4 py-3 text-left transition-all duration-300 ease-atlas lg:whitespace-normal"
                    style={{
                      borderColor: isActive ? s.accent : 'rgba(255,255,255,0.1)',
                      background: isActive ? 'rgba(255,255,255,0.06)' : 'transparent'
                    }}>
                    
                    <span
                      className="h-2 w-2 shrink-0 rounded-full transition-transform duration-300"
                      style={{ background: s.accent, transform: isActive ? 'scale(1.3)' : 'scale(1)' }} />
                    
                    <span className="flex-1">
                      <span className={`block text-[15px] font-medium ${isActive ? 'text-white' : 'text-white/65'}`}>
                        {s.name}
                      </span>
                      <span className="hidden text-[12px] text-white/40 lg:block">{s.short}</span>
                    </span>
                  </button>
                </li>);

            })}
          </ul>

          <div className="relative min-h-[440px]">
            <AnimatePresence mode="wait">
              <motion.div
                key={service.slug}
                initial={{ opacity: 0, y: 16 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -12 }}
                transition={{ duration: 0.4, ease: [0.22, 1, 0.36, 1] }}
                className="rounded-feature border border-white/10 bg-white/[0.03] p-6 backdrop-blur-sm sm:p-9">
                
                <div className="flex flex-wrap items-start justify-between gap-4">
                  <div>
                    <h3 className="text-h2 font-semibold text-white">{service.name}</h3>
                    <p className="mt-3 max-w-xl text-bodylg text-white/60">{service.description}</p>
                  </div>
                  <Link
                    to={`/services/${service.slug}`}
                    className="inline-flex items-center gap-1.5 rounded-control border border-white/15 px-3 py-2 text-[13px] text-white/80 transition-colors hover:border-white/40 hover:text-white">
                    
                    Explore
                    <ArrowUpRightIcon className="h-3.5 w-3.5" aria-hidden="true" />
                  </Link>
                </div>

                <div className="mt-9">
                  <span className="label text-white/35">System preview</span>
                  <div className="mt-4">
                    <FlowStrip steps={service.flow} accent={service.accent} />
                  </div>
                </div>

                <div className="mt-9 grid gap-8 sm:grid-cols-2">
                  <div>
                    <span className="label text-white/35">Capabilities</span>
                    <ul className="mt-3 space-y-1.5">
                      {service.capabilities.map((c) =>
                      <li key={c} className="text-[13px] text-white/70">
                          {c}
                        </li>
                      )}
                    </ul>
                  </div>
                  <div>
                    <span className="label text-white/35">What we measure</span>
                    <ul className="mt-3 flex flex-wrap gap-2">
                      {service.metricCategories.map((m) =>
                      <li
                        key={m}
                        className="rounded-full border px-2.5 py-1 text-[12px]"
                        style={{ borderColor: `${service.accent}55`, color: service.accent }}>
                        
                          {m}
                        </li>
                      )}
                    </ul>
                    <p className="mt-4 text-[11px] text-white/35">
                      Metric categories, not claimed results. Numbers appear once they are measured.
                    </p>
                  </div>
                </div>
              </motion.div>
            </AnimatePresence>
          </div>
        </div>
      </div>
    </section>);

}