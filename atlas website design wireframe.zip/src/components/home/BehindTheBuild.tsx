import React from 'react';
import { motion } from 'framer-motion';
import { images } from '../../data/site';
import { SectionLabel } from '../ui/Section';
import { Reveal } from '../ui/Reveal';

const annotations = [
{ label: 'Discovery', note: 'Process mapped before anything is designed' },
{ label: 'Wireframes', note: 'Hierarchy decided in grey, not in colour' },
{ label: 'Architecture', note: 'Data model first, interface second' },
{ label: 'Evaluation', note: 'Agent decisions scored against real outcomes' }];


export function BehindTheBuild() {
  return (
    <section className="w-full bg-base-soft py-20 md:py-30" aria-labelledby="behind-title">
      <div className="mx-auto max-w-site px-5 sm:px-8">
        <SectionLabel accent="#25D9FF">Behind the build</SectionLabel>
        <Reveal>
          <h2 id="behind-title" className="mt-6 max-w-2xl text-h1 font-semibold">
            The work behind the work.
          </h2>
        </Reveal>

        <div className="mt-14 grid gap-4 md:grid-cols-12">
          <Reveal className="md:col-span-7">
            <figure className="overflow-hidden rounded-feature border border-ink/10 bg-white">
              <img
                src={images.artifacts}
                alt="Overhead view of a desk covered in printed low-fidelity wireframe sheets with a tablet showing a dark dashboard interface, sticky notes and a pencil."
                loading="lazy"
                className="aspect-[4/3] w-full object-cover" />
              
              <figcaption className="flex items-center justify-between px-5 py-3.5 text-[12px] text-ink-muted">
                <span>Wireframes before visual design</span>
                <span className="label text-ink-faint">Discovery</span>
              </figcaption>
            </figure>
          </Reveal>

          <div className="grid gap-4 md:col-span-5">
            <Reveal delay={0.06}>
              <figure className="overflow-hidden rounded-feature border border-ink/10 bg-ink">
                <img
                  src={images.screens}
                  alt="Close-up of a laptop screen showing an abstract analytics dashboard with electric blue and cyan data lines in a dark studio environment."
                  loading="lazy"
                  className="aspect-[16/9] w-full object-cover" />
                
              </figure>
            </Reveal>

            <div className="rounded-feature border border-ink/10 bg-white p-6">
              <span className="label text-ink-faint">Annotations</span>
              <ul className="mt-4 space-y-3.5">
                {annotations.map((a, i) =>
                <motion.li
                  key={a.label}
                  initial={{ opacity: 0, x: -8 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.35, delay: i * 0.06 }}
                  className="flex gap-3">
                  
                    <span
                    className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full"
                    style={{ background: ['#2457FF', '#B7FF3C', '#25D9FF', '#FF3CAC'][i] }}
                    aria-hidden="true" />
                  
                    <span>
                      <span className="block text-[13px] font-medium text-ink">{a.label}</span>
                      <span className="block text-[12px] text-ink-muted">{a.note}</span>
                    </span>
                  </motion.li>
                )}
              </ul>
            </div>
          </div>

          <Reveal delay={0.05} className="md:col-span-5">
            <figure className="h-full overflow-hidden rounded-feature border border-ink/10">
              <img
                src={images.hands}
                alt="Hands holding a tablet displaying a minimal workflow diagram of connected nodes, on a warm desk in natural light."
                loading="lazy"
                className="h-full min-h-[220px] w-full object-cover" />
              
            </figure>
          </Reveal>

          <Reveal delay={0.08} className="md:col-span-7">
            <div className="flex h-full flex-col justify-between rounded-feature border border-ink/10 bg-ink p-7 text-white sm:p-9">
              <div className="grid grid-cols-2 gap-x-6 gap-y-5 sm:grid-cols-3">
                {['Discovery', 'Wireframes', 'Design iterations', 'Prototypes', 'Architecture', 'AI workflows', 'Code review', 'Testing', 'Deployment'].map(
                  (item) =>
                  <span key={item} className="text-[13px] text-white/65">
                      {item}
                    </span>

                )}
              </div>
              <p className="mt-8 max-w-lg text-sm text-white/50">
                Every engagement leaves a paper trail: what was decided, why, and what it cost. It is the part
                that makes the second project faster than the first.
              </p>
            </div>
          </Reveal>
        </div>
      </div>
    </section>);

}