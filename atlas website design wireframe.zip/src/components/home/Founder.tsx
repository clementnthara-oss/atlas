import React from 'react';
import { SectionLabel } from '../ui/Section';
import { Reveal } from '../ui/Reveal';
import { CTAButton } from '../ui/CTAButton';

const promises = [
{ title: 'Direct founder access', body: 'You talk to the person building it, not an account manager relaying messages.' },
{ title: 'Direct communication', body: 'Regular check-ins throughout, in plain language, including when something is harder than expected.' },
{ title: 'Technical ownership', body: 'The person who designs the system is accountable for whether it works in production.' },
{ title: 'Strategic involvement', body: 'Every recommendation is judged on revenue, trust or efficiency — not on how impressive it sounds.' },
{ title: 'Long-term partnership', body: 'Launch is the start. We stay involved as the business changes shape.' }];


export function Founder() {
  return (
    <section className="w-full bg-base-soft py-20 md:py-30" aria-labelledby="founder-title">
      <div className="mx-auto max-w-site px-5 sm:px-8">
        <div className="grid gap-10 lg:grid-cols-[1fr_1.15fr] lg:gap-16">
          <div>
            <SectionLabel>Founder</SectionLabel>
            <Reveal>
              <h2 id="founder-title" className="mt-6 text-h1 font-semibold">
                You&rsquo;ll work with the people building it.
              </h2>
            </Reveal>
            <Reveal delay={0.06}>
              <p className="mt-6 max-w-lg text-bodylg text-ink-muted">
                AIG is small on purpose. The person who understands your business is the person designing the
                system and shipping the code — which is why nothing gets lost between the brief and the build.
              </p>
            </Reveal>

            <div className="mt-9 flex flex-wrap gap-3">
              <CTAButton to="/contact">Book a Call</CTAButton>
              <CTAButton to="/about" variant="secondary">
                More about AIG
              </CTAButton>
            </div>

            <div className="mt-10 flex items-center gap-4 rounded-card border border-dashed border-ink/20 bg-white p-4">
              <div
                className="flex h-14 w-14 shrink-0 items-center justify-center rounded-full bg-base-soft text-[11px] text-ink-faint"
                aria-hidden="true">
                
                AIG
              </div>
              <p className="text-[12px] leading-relaxed text-ink-muted">
                Founder photography slot — reserved for the real image. No stock portrait is used here.
              </p>
            </div>
          </div>

          <ul className="grid gap-3 sm:grid-cols-2">
            {promises.map((p, i) =>
            <li key={p.title} className={i === 0 ? 'sm:col-span-2' : ''}>
                <Reveal delay={i * 0.05} className="h-full">
                  <div className="h-full rounded-feature border border-ink/10 bg-white p-6">
                    <span className="label text-atlas">{String(i + 1).padStart(2, '0')}</span>
                    <h3 className="mt-3 text-h4 font-semibold">{p.title}</h3>
                    <p className="mt-2.5 text-[13px] leading-relaxed text-ink-muted">{p.body}</p>
                  </div>
                </Reveal>
              </li>
            )}
          </ul>
        </div>
      </div>
    </section>);

}