import React from 'react';
import { motion } from 'framer-motion';
import { studioProducts } from '../../data/studio';
import { SectionLabel } from '../ui/Section';
import { CTAButton } from '../ui/CTAButton';

export function ProductStudio() {
  return (
    <section
      className="relative w-full overflow-hidden py-20 md:py-30"
      style={{ background: 'linear-gradient(160deg, #7C3AED 0%, #08090B 55%, #FF3CAC 130%)' }}
      aria-labelledby="studio-title">
      
      <div className="pointer-events-none absolute inset-0 dot-grid opacity-25" aria-hidden="true" />
      <div className="relative mx-auto max-w-site px-5 sm:px-8">
        <SectionLabel tone="dark" accent="#B7FF3C">
          Product Studio
        </SectionLabel>
        <div className="mt-6 flex flex-wrap items-end justify-between gap-6">
          <h2 id="studio-title" className="max-w-2xl text-h1 font-semibold text-white">
            We don&rsquo;t only build for clients.
            <span className="block text-white/50">We build what should exist.</span>
          </h2>
          <CTAButton to="/product-studio" variant="onDark">
            Enter the studio
          </CTAButton>
        </div>

        <ul className="mt-14 grid gap-4 md:grid-cols-2">
          {studioProducts.map((p, i) =>
          <motion.li
            key={p.name}
            initial={{ opacity: 0, y: 22 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-60px' }}
            transition={{ duration: 0.5, delay: i * 0.06, ease: [0.22, 1, 0.36, 1] }}
            className="group rounded-feature border border-white/12 bg-white/[0.05] p-7 backdrop-blur-sm transition-colors duration-300 hover:border-white/30">
            
              <div className="flex items-center justify-between gap-4">
                <h3 className="text-h3 font-semibold text-white">{p.name}</h3>
                <span
                className="shrink-0 rounded-full px-2.5 py-1 text-[11px] font-medium"
                style={{ background: p.accent, color: '#08090B' }}>
                
                  {p.status}
                </span>
              </div>
              <dl className="mt-6 space-y-4">
                {[
              ['Problem', p.problem],
              ['Market', p.market],
              ['Product', p.product],
              ['Technology', p.technology]].
              map(([term, desc]) =>
              <div key={term} className="grid grid-cols-[92px_1fr] gap-3">
                    <dt className="label pt-0.5 text-white/35">{term}</dt>
                    <dd className="text-[13px] leading-relaxed text-white/75">{desc}</dd>
                  </div>
              )}
              </dl>
              <p className="mt-6 border-t border-white/10 pt-5 text-[13px] italic leading-relaxed text-white/55">
                &ldquo;{p.learning}&rdquo;
              </p>
            </motion.li>
          )}
        </ul>
      </div>
    </section>);

}