import React from 'react';
import { motion } from 'framer-motion';
import { SectionLabel } from '../ui/Section';

const ai = ['Research', 'Generate', 'Prototype', 'Analyze', 'Automate', 'Test', 'Iterate'];
const human = ['Understand', 'Question', 'Decide', 'Design', 'Validate', 'Take responsibility'];

export function AIAndHuman() {
  return (
    <section className="w-full bg-base py-20 md:py-30" aria-labelledby="aihuman-title">
      <div className="mx-auto max-w-site px-5 sm:px-8">
        <SectionLabel accent="#61FF8E">AI + human</SectionLabel>
        <h2 id="aihuman-title" className="mt-6 max-w-3xl text-h1 font-semibold">
          AI accelerates the work.
          <span className="block text-ink-faint">Human judgment decides what deserves to ship.</span>
        </h2>

        <div className="mt-14 grid gap-4 md:grid-cols-2">
          <div className="rounded-feature border border-ink/10 bg-ink p-7 sm:p-9">
            <div className="flex items-center justify-between">
              <span className="label text-grass">AI</span>
              <span className="text-[11px] text-white/35">Speed &middot; volume &middot; recall</span>
            </div>
            <ul className="mt-7 space-y-2.5">
              {ai.map((item, i) =>
              <motion.li
                key={item}
                initial={{ opacity: 0, x: -10 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.3, delay: i * 0.05 }}
                className="flex items-center gap-3 rounded-control border border-white/10 bg-white/[0.04] px-4 py-3">
                
                  <span className="h-1.5 w-1.5 rounded-full bg-grass" aria-hidden="true" />
                  <span className="text-[14px] text-white/85">{item}</span>
                </motion.li>
              )}
            </ul>
          </div>

          <div className="rounded-feature border border-ink/10 bg-white p-7 sm:p-9">
            <div className="flex items-center justify-between">
              <span className="label text-atlas">Human</span>
              <span className="text-[11px] text-ink-faint">Judgment &middot; context &middot; accountability</span>
            </div>
            <ul className="mt-7 space-y-2.5">
              {human.map((item, i) =>
              <motion.li
                key={item}
                initial={{ opacity: 0, x: 10 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.3, delay: i * 0.05 }}
                className="flex items-center gap-3 rounded-control border border-ink/10 bg-base px-4 py-3">
                
                  <span className="h-1.5 w-1.5 rounded-full bg-atlas" aria-hidden="true" />
                  <span className="text-[14px] text-ink">{item}</span>
                </motion.li>
              )}
            </ul>
            <p className="mt-7 text-[13px] leading-relaxed text-ink-muted">
              A model can produce ten options in a minute. Deciding which one a business should live with for
              the next three years is not a generation problem.
            </p>
          </div>
        </div>
      </div>
    </section>);

}