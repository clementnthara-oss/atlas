import React from 'react';
import { motion } from 'framer-motion';
import { beliefs } from '../../data/site';
import { SectionLabel } from '../ui/Section';

export function Beliefs() {
  return (
    <section className="w-full border-y border-ink/10 bg-white py-20 md:py-30" aria-labelledby="beliefs-title">
      <div className="mx-auto max-w-site px-5 sm:px-8">
        <SectionLabel>Beliefs</SectionLabel>
        <h2 id="beliefs-title" className="mt-6 max-w-2xl text-h1 font-semibold">
          What we hold to, even when it costs us the job.
        </h2>

        <ul className="mt-14 divide-y divide-ink/10 border-t border-ink/10">
          {beliefs.map((b, i) =>
          <motion.li
            key={b.title}
            initial={{ opacity: 0, y: 18 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-60px' }}
            transition={{ duration: 0.5, delay: i % 3 * 0.05, ease: [0.22, 1, 0.36, 1] }}
            className="grid gap-3 py-8 md:grid-cols-[80px_1fr_1.2fr] md:items-baseline md:gap-8">
            
              <span className="label text-ink-faint">{String(i + 1).padStart(2, '0')}</span>
              <h3 className="text-h3 font-semibold tracking-tight">{b.title}</h3>
              <p className="text-bodylg text-ink-muted">{b.body}</p>
            </motion.li>
          )}
        </ul>
      </div>
    </section>);

}