import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { SectionLabel } from '../ui/Section';
import { Reveal } from '../ui/Reveal';

const stages = [
{ name: 'Understand', question: 'What is happening?', detail: 'The business, the customers, the process as it really runs — not as the org chart says it does.' },
{ name: 'Diagnose', question: 'Where is the friction?', detail: 'Find the steps that cost the most and contribute the least, and the places value leaks out unnoticed.' },
{ name: 'Prioritize', question: 'Where is the highest-value opportunity?', detail: 'Rank by value, effort, risk and time to impact. Most things do not make the list.' },
{ name: 'Decide', question: 'Build, integrate, automate, redesign — or don\u2019t build?', detail: 'Sometimes the honest answer is a process change. We say so.' },
{ name: 'Execute', question: 'How does the decision become real?', detail: 'A sequenced plan with owners, measurement and a defined first outcome.' }];


export function Consultancy() {
  const [open, setOpen] = useState(0);

  return (
    <section className="w-full bg-base-soft py-20 md:py-30" aria-labelledby="consult-title">
      <div className="mx-auto max-w-site px-5 sm:px-8">
        <div className="mx-auto max-w-3xl text-center">
          <div className="flex justify-center">
            <SectionLabel accent="#7C3AED">Consultancy</SectionLabel>
          </div>
          <Reveal>
            <h2 id="consult-title" className="mt-6 text-h1 font-semibold">
              Sometimes the right answer isn&rsquo;t to build anything.
            </h2>
          </Reveal>
          <Reveal delay={0.06}>
            <p className="mt-6 text-bodylg text-ink-muted">
              Before design or code, we work out where AI or software actually helps — and where it does not.
            </p>
          </Reveal>
        </div>

        <div className="mx-auto mt-14 max-w-4xl overflow-hidden rounded-feature border border-ink/10 bg-white">
          {stages.map((s, i) => {
            const isOpen = open === i;
            return (
              <div key={s.name} className="border-b border-ink/8 last:border-b-0">
                <h3>
                  <button
                    type="button"
                    onClick={() => setOpen(isOpen ? -1 : i)}
                    aria-expanded={isOpen}
                    className="flex w-full items-center gap-5 px-6 py-5 text-left transition-colors hover:bg-base sm:px-8">
                    
                    <span className="label w-6 text-ink-faint">{String(i + 1).padStart(2, '0')}</span>
                    <span className="w-32 shrink-0 text-[15px] font-semibold text-ink sm:w-40">{s.name}</span>
                    <span className={`flex-1 text-[14px] ${isOpen ? 'text-ink' : 'text-ink-muted'}`}>
                      {s.question}
                    </span>
                    <motion.span
                      animate={{ rotate: isOpen ? 45 : 0 }}
                      transition={{ duration: 0.25 }}
                      className="text-lg leading-none text-ink-faint"
                      aria-hidden="true">
                      
                      +
                    </motion.span>
                  </button>
                </h3>
                <motion.div
                  initial={false}
                  animate={{ height: isOpen ? 'auto' : 0, opacity: isOpen ? 1 : 0 }}
                  transition={{ duration: 0.32, ease: [0.22, 1, 0.36, 1] }}
                  className="overflow-hidden">
                  
                  <p className="px-6 pb-6 pl-[68px] text-[14px] leading-relaxed text-ink-muted sm:px-8 sm:pl-[92px]">
                    {s.detail}
                  </p>
                </motion.div>
              </div>);

          })}
        </div>
      </div>
    </section>);

}