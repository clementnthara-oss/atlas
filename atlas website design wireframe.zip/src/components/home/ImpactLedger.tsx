import React from 'react';
import { motion } from 'framer-motion';
import { ledger } from '../../data/site';
import { SectionLabel } from '../ui/Section';

export function ImpactLedger() {
  return (
    <section className="w-full bg-ink py-20 md:py-30" aria-labelledby="ledger-title">
      <div className="mx-auto max-w-site px-5 sm:px-8">
        <div className="flex flex-wrap items-end justify-between gap-6">
          <div>
            <SectionLabel tone="dark" accent="#25D9FF">
              Impact ledger
            </SectionLabel>
            <h2 id="ledger-title" className="mt-6 max-w-2xl text-h1 font-semibold text-white">
              Numbers go here when they are real.
            </h2>
          </div>
          <p className="max-w-sm text-sm text-white/55">
            The ledger is built and instrumented. It stays empty until there are verified, sourced figures to
            put in it.
          </p>
        </div>

        <dl className="mt-14 grid gap-px overflow-hidden rounded-feature border border-white/12 bg-white/10 sm:grid-cols-2 lg:grid-cols-3">
          {ledger.map((item, i) =>
          <motion.div
            key={item.name}
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.4, delay: i * 0.04 }}
            className="bg-ink p-7">
            
              <dt className="text-[13px] text-white/55">{item.name}</dt>
              <dd className="mt-4 flex items-baseline gap-3">
                <span className="text-h2 font-semibold tabular-nums text-white/25">&mdash;&mdash;</span>
                <span className="rounded-full border border-white/15 px-2.5 py-1 text-[11px] text-white/50">
                  Not yet measured
                </span>
              </dd>
              <p className="mt-4 text-[12px] text-white/35">{item.note}</p>
            </motion.div>
          )}
        </dl>
      </div>
    </section>);

}