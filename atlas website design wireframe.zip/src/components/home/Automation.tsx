import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { SectionLabel } from '../ui/Section';
import { Reveal } from '../ui/Reveal';

const before = [
'Lead arrives',
'Employee reads it',
'Searches for information',
'Updates the CRM',
'Sends a response',
'Creates a reminder'];


const after = ['Lead arrives', 'Understands', 'Qualifies', 'Updates', 'Responds', 'Follows up', 'Reports'];

export function Automation() {
  const [view, setView] = useState<'before' | 'after'>('after');
  const steps = view === 'before' ? before : after;
  const accent = view === 'before' ? '#8A8D96' : '#FF8A3D';

  return (
    <section className="w-full bg-base py-20 md:py-30" aria-labelledby="automation-title">
      <div className="mx-auto max-w-site px-5 sm:px-8">
        <div className="flex flex-wrap items-end justify-between gap-6">
          <div>
            <SectionLabel accent="#FF8A3D">Automation</SectionLabel>
            <Reveal>
              <h2 id="automation-title" className="mt-6 max-w-2xl text-h1 font-semibold">
                The same job, with the manual steps removed.
              </h2>
            </Reveal>
          </div>

          <div
            className="inline-flex rounded-control border border-ink/12 bg-white p-1"
            role="group"
            aria-label="Compare workflow">
            
            {(['before', 'after'] as const).map((v) =>
            <button
              key={v}
              type="button"
              onClick={() => setView(v)}
              aria-pressed={view === v}
              className={`rounded-[5px] px-4 py-2 text-[13px] font-medium capitalize transition-colors duration-200 ${
              view === v ? 'bg-ink text-white' : 'text-ink-muted hover:text-ink'}`
              }>
              
                {v}
              </button>
            )}
          </div>
        </div>

        <div className="mt-12 grid gap-4 md:grid-cols-2">
          <div className="rounded-feature border border-ink/10 bg-white p-6 sm:p-8">
            <div className="flex items-center justify-between">
              <span className="label text-ink-faint">Before</span>
              <span className="label text-ink-faint">{before.length} human steps</span>
            </div>
            <ol className="mt-6 space-y-2.5">
              {before.map((s, i) =>
              <li key={s} className="flex items-center gap-3">
                  <span className="label w-5 text-ink-faint">{i + 1}</span>
                  <span className="flex-1 rounded-control border border-ink/10 bg-base px-3 py-2.5 text-[13px] text-ink-muted">
                    {s}
                  </span>
                </li>
              )}
            </ol>
          </div>

          <div className="rounded-feature border border-ink/10 bg-ink p-6 text-white sm:p-8">
            <div className="flex items-center justify-between">
              <span className="label text-orange">After</span>
              <span className="label text-white/40">1 human decision</span>
            </div>
            <ol className="mt-6 space-y-2.5">
              {after.map((s, i) =>
              <li key={s} className="flex items-center gap-3">
                  <span className="label w-5 text-white/30">{i + 1}</span>
                  <motion.span
                  initial={{ opacity: 0, x: -8 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.35, delay: i * 0.05 }}
                  className="flex-1 rounded-control border px-3 py-2.5 text-[13px]"
                  style={{
                    borderColor: i === 0 || i === after.length - 1 ? '#FF8A3D' : 'rgba(255,255,255,0.12)',
                    background: 'rgba(255,255,255,0.04)',
                    color: 'rgba(255,255,255,0.85)'
                  }}>
                  
                    {i > 0 && i < after.length - 1 &&
                  <span className="mr-2 text-[10px] uppercase tracking-[0.12em] text-orange">AIG</span>
                  }
                    {s}
                  </motion.span>
                </li>
              )}
            </ol>
          </div>
        </div>

        {/* Time comparison — relative, unquantified */}
        <div className="mt-6 rounded-feature border border-ink/10 bg-white p-6 sm:p-8">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <span className="label text-ink-faint">Relative elapsed time</span>
            <span className="rounded-full border border-ink/12 px-2.5 py-1 text-[11px] text-ink-muted">
              Illustrative workflow &middot; not yet measured
            </span>
          </div>
          <div className="mt-6 space-y-4">
            {[
            { name: 'Before', width: '100%', color: '#E5E4DF', text: '#08090B' },
            { name: 'After', width: '22%', color: '#FF8A3D', text: '#08090B' }].
            map((row) =>
            <div key={row.name} className="flex items-center gap-4">
                <span className="w-14 text-[12px] text-ink-muted">{row.name}</span>
                <div className="h-8 flex-1 overflow-hidden rounded-control bg-base-soft">
                  <motion.div
                  className="h-full rounded-control"
                  style={{ background: row.color }}
                  initial={{ width: 0 }}
                  whileInView={{ width: row.width }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.9, ease: [0.22, 1, 0.36, 1] }} />
                
                </div>
              </div>
            )}
          </div>
          <p className="mt-5 max-w-2xl text-[12px] text-ink-faint">
            The bars show the shape of the change, not a claimed figure. Real time savings are baselined and
            measured per engagement before they are ever published.
          </p>
        </div>

        <p className="sr-only">
          Currently showing the {view} workflow with {steps.length} steps.
        </p>
      </div>
    </section>);

}