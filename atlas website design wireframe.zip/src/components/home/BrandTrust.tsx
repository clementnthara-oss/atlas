import React from 'react';
import { motion } from 'framer-motion';
import { SectionLabel } from '../ui/Section';
import { Reveal } from '../ui/Reveal';
import { images } from '../../data/site';

const chain = [
{ step: 'Identity', accent: '#FF3CAC' },
{ step: 'Website', accent: '#FF4FD8' },
{ step: 'Product', accent: '#7C3AED' },
{ step: 'Customer experience', accent: '#2457FF' },
{ step: 'Trust', accent: '#FFFFFF' }];


export function BrandTrust() {
  return (
    <section className="relative w-full overflow-hidden bg-ink py-20 md:py-30" aria-labelledby="brand-title">
      <div
        className="pointer-events-none absolute inset-0"
        style={{
          background:
          'linear-gradient(140deg, rgba(255,60,172,0.35) 0%, rgba(8,9,11,0.9) 45%, rgba(124,58,237,0.28) 100%)'
        }}
        aria-hidden="true" />
      
      <div className="relative mx-auto max-w-site px-5 sm:px-8">
        <SectionLabel tone="dark" accent="#FF3CAC">
          Brand &amp; trust
        </SectionLabel>
        <Reveal>
          <h2 id="brand-title" className="mt-6 max-w-3xl text-h1 font-semibold text-white">
            Make the business look as capable as it actually is.
          </h2>
        </Reveal>

        <div className="mt-14 grid gap-6 lg:grid-cols-[1.3fr_1fr]">
          <Reveal className="overflow-hidden rounded-feature border border-white/12">
            <img
              src={images.brand}
              alt="Printed brand identity artifacts: logo cards, a magenta and blue colour swatch strip, a folded typographic poster and a matte business card arranged on a warm white surface."
              loading="lazy"
              className="h-full w-full object-cover" />
            
          </Reveal>

          <div className="flex flex-col gap-6">
            <div className="rounded-feature border border-white/12 bg-white/[0.05] p-6 backdrop-blur-sm sm:p-8">
              <span className="label text-white/40">The chain</span>
              <ol className="mt-5 space-y-3">
                {chain.map((c, i) =>
                <motion.li
                  key={c.step}
                  initial={{ opacity: 0, x: -10 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.4, delay: i * 0.07, ease: [0.22, 1, 0.36, 1] }}
                  className="flex items-center gap-3">
                  
                    <span className="h-6 w-px" style={{ background: c.accent, opacity: i === 0 ? 0 : 0.5 }} aria-hidden="true" />
                    <span
                    className="flex-1 rounded-control border px-3.5 py-2.5 text-[13px]"
                    style={{
                      borderColor: `${c.accent}55`,
                      color: c.accent === '#FFFFFF' ? '#08090B' : '#FFFFFF',
                      background: c.accent === '#FFFFFF' ? '#FFFFFF' : 'rgba(255,255,255,0.04)'
                    }}>
                    
                      {c.step}
                    </span>
                  </motion.li>
                )}
              </ol>
            </div>

            <div className="grid grid-cols-3 gap-3">
              {[
              { name: 'Type', preview: 'Aa', bg: '#FFFFFF', fg: '#08090B' },
              { name: 'Colour', preview: '', bg: '#FF3CAC', fg: '#FFFFFF' },
              { name: 'Mark', preview: '◎', bg: '#7C3AED', fg: '#FFFFFF' }].
              map((tile) =>
              <div
                key={tile.name}
                className="flex aspect-square flex-col justify-between rounded-card p-4"
                style={{ background: tile.bg, color: tile.fg }}>
                
                  <span className="text-2xl font-semibold" aria-hidden="true">
                    {tile.preview}
                  </span>
                  <span className="label opacity-70">{tile.name}</span>
                </div>
              )}
            </div>
          </div>
        </div>

        <p className="mt-8 max-w-2xl text-sm text-white/55">
          Identity, design language and application, built so that a stranger takes the business seriously
          before anyone has spoken to them.
        </p>
      </div>
    </section>);

}