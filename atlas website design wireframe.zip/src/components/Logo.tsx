import React from 'react';

interface LogoProps {
  tone?: 'ink' | 'light';
  className?: string;
}

/**
 * Placeholder AIG mark. When the official logo asset is supplied it should be
 * dropped in here unmodified — geometry preserved, no effects added.
 */
export function Logo({ tone = 'ink', className = '' }: LogoProps) {
  const fg = tone === 'light' ? '#FFFFFF' : '#08090B';
  return (
    <span className={`inline-flex items-center gap-2.5 ${className}`}>
      <svg width="26" height="26" viewBox="0 0 26 26" fill="none" aria-hidden="true">
        <rect x="0.75" y="0.75" width="24.5" height="24.5" rx="7" stroke={fg} strokeWidth="1.5" />
        <circle cx="13" cy="13" r="3.25" fill="#2457FF" />
        <path d="M13 3.5v6.2M13 16.3v6.2M3.5 13h6.2M16.3 13h6.2" stroke={fg} strokeWidth="1.5" strokeLinecap="round" />
      </svg>
      <span
        className="text-[15px] font-semibold tracking-[-0.02em]"
        style={{ color: fg }}>
        
        Atlas Intelligence
      </span>
    </span>);

}