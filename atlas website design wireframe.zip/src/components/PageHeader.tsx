import React from 'react';
import { motion } from 'framer-motion';
import { SectionLabel } from './ui/Section';

interface PageHeaderProps {
  label: string;
  title: React.ReactNode;
  lede?: React.ReactNode;
  accent?: string;
  tone?: 'light' | 'dark';
  gradient?: string;
  children?: React.ReactNode;
}

export function PageHeader({
  label,
  title,
  lede,
  accent = '#2457FF',
  tone = 'light',
  gradient,
  children
}: PageHeaderProps) {
  const dark = tone === 'dark';
  return (
    <header
      className={`relative w-full overflow-hidden ${dark ? 'bg-ink' : 'bg-base'} py-16 md:py-24`}>
      
      {gradient &&
      <div className="pointer-events-none absolute inset-0" style={{ background: gradient }} aria-hidden="true" />
      }
      {!gradient && !dark &&
      <div className="pointer-events-none absolute inset-0 grid-lines opacity-40" aria-hidden="true" />
      }
      <div className="relative mx-auto max-w-site px-5 sm:px-8">
        <SectionLabel tone={dark ? 'dark' : 'light'} accent={accent}>
          {label}
        </SectionLabel>
        <motion.h1
          initial={{ opacity: 0, y: 18 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
          className={`mt-6 max-w-4xl text-h1 font-semibold ${dark ? 'text-white' : 'text-ink'}`}>
          
          {title}
        </motion.h1>
        {lede &&
        <motion.p
          initial={{ opacity: 0, y: 14 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.08, ease: [0.22, 1, 0.36, 1] }}
          className={`mt-6 max-w-2xl text-bodylg ${dark ? 'text-white/65' : 'text-ink-muted'}`}>
          
            {lede}
          </motion.p>
        }
        {children && <div className="mt-9">{children}</div>}
      </div>
    </header>);

}