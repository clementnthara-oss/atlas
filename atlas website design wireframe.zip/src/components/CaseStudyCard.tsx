import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { ArrowUpRightIcon } from 'lucide-react';
import { CaseStudy } from '../types/content';
import { services } from '../data/services';

interface Props {
  study: CaseStudy;
  index: number;
}

export function CaseStudyCard({ study, index }: Props) {
  const related = study.services.
  map((slug) => services.find((s) => s.slug === slug)?.name).
  filter(Boolean) as string[];

  return (
    <motion.article
      initial={{ opacity: 0, y: 24 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: '-60px' }}
      transition={{ duration: 0.55, delay: index * 0.05, ease: [0.22, 1, 0.36, 1] }}
      className="group relative overflow-hidden rounded-feature border border-ink/10 bg-white">
      
      <Link to={`/work/${study.slug}`} className="grid gap-0 md:grid-cols-[1fr_1.15fr]">
        <div
          className="relative min-h-[220px] overflow-hidden p-7"
          style={{
            background: `linear-gradient(150deg, ${study.accent} 0%, #08090B 78%)`
          }}>
          
          <div className="absolute inset-0 dot-grid opacity-40" aria-hidden="true" />
          <div className="relative flex h-full flex-col justify-between">
            <span className="label text-white/70">{study.industry}</span>
            <div className="space-y-3">
              {['Problem', 'Approach', 'Result'].map((step, i) =>
              <div key={step} className="flex items-center gap-3">
                  <span className="h-1.5 w-1.5 rounded-full bg-white/60" aria-hidden="true" />
                  <span className="h-px flex-1 bg-white/25" aria-hidden="true" />
                  <span className="text-[11px] text-white/80">{step}</span>
                </div>
              )}
            </div>
          </div>
        </div>

        <div className="flex flex-col p-7 sm:p-9">
          <div className="flex items-center gap-3">
            <span className="rounded-full border border-ink/12 px-2.5 py-1 text-[11px] text-ink-muted">
              {study.status}
            </span>
            <span className="text-[11px] text-ink-faint">{study.client}</span>
          </div>
          <h3 className="mt-5 text-h3 font-semibold text-ink">{study.summary}</h3>
          <p className="mt-4 line-clamp-3 text-sm leading-relaxed text-ink-muted">{study.problem}</p>

          <div className="mt-6 flex flex-wrap gap-2">
            {related.map((r) =>
            <span key={r} className="rounded-full bg-base-soft px-2.5 py-1 text-[11px] text-ink-muted">
                {r}
              </span>
            )}
          </div>

          <span className="mt-7 inline-flex items-center gap-1.5 text-[13px] font-medium text-ink transition-colors group-hover:text-atlas">
            Read the full breakdown
            <ArrowUpRightIcon className="h-3.5 w-3.5 transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" aria-hidden="true" />
          </span>
        </div>
      </Link>
    </motion.article>);

}