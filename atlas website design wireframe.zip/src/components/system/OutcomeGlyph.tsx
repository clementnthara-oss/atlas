import React from 'react';
import { motion } from 'framer-motion';
import { OutcomeKey } from '../../types/content';

interface Props {
  outcome: OutcomeKey;
  active: boolean;
  accent: string;
  ink: string;
}

/** Four distinct diagrammatic treatments — one per business outcome. */
export function OutcomeGlyph({ outcome, active, accent, ink }: Props) {
  const stroke = active ? ink : accent;
  const faint = active ? ink === '#FFFFFF' ? 'rgba(255,255,255,0.35)' : 'rgba(8,9,11,0.25)' : 'rgba(8,9,11,0.14)';

  if (outcome === 'revenue') {
    // Conversion funnel narrowing into a sale
    return (
      <svg viewBox="0 0 120 90" className="h-full w-full" aria-hidden="true">
        {[0, 1, 2, 3].map((i) =>
        <motion.rect
          key={i}
          x={10 + i * 8}
          y={8 + i * 18}
          width={100 - i * 16}
          height="12"
          rx="3"
          fill={i === 3 ? stroke : faint}
          animate={{ opacity: active ? 1 : 0.7, x: active ? 0 : -2 }}
          transition={{ duration: 0.4, delay: i * 0.05 }} />

        )}
        <motion.path
          d="M60 74 v10"
          stroke={stroke}
          strokeWidth="2"
          animate={{ opacity: active ? 1 : 0.4 }} />
        
      </svg>);

  }

  if (outcome === 'efficiency') {
    // Automation pipeline — steps collapsing
    return (
      <svg viewBox="0 0 120 90" className="h-full w-full" aria-hidden="true">
        <line x1="8" y1="30" x2="112" y2="30" stroke={faint} strokeWidth="2" />
        {[8, 34, 60, 86, 112].map((x, i) =>
        <motion.circle
          key={x}
          cx={x}
          cy="30"
          r={i === 2 ? 7 : 4}
          fill={i === 2 ? stroke : faint}
          animate={{ scale: active ? 1 : 0.85 }}
          transition={{ duration: 0.4, delay: i * 0.05 }} />

        )}
        <motion.line
          x1="8"
          y1="30"
          x2="112"
          y2="30"
          stroke={stroke}
          strokeWidth="2"
          initial={false}
          animate={{ pathLength: active ? 1 : 0.2 }}
          transition={{ duration: 0.7, ease: [0.22, 1, 0.36, 1] }} />
        
        <line x1="8" y1="66" x2="112" y2="66" stroke={faint} strokeWidth="2" strokeDasharray="4 5" />
        <motion.rect x="8" y="61" width="44" height="10" rx="5" fill={stroke} animate={{ width: active ? 30 : 90 }} transition={{ duration: 0.6 }} />
      </svg>);

  }

  if (outcome === 'trust') {
    // Brand → customer confidence
    return (
      <svg viewBox="0 0 120 90" className="h-full w-full" aria-hidden="true">
        <motion.rect x="10" y="14" width="42" height="30" rx="6" fill={faint} animate={{ y: active ? 10 : 14 }} transition={{ duration: 0.5 }} />
        <motion.rect x="24" y="30" width="42" height="30" rx="6" fill={active ? stroke : faint} animate={{ y: active ? 28 : 30 }} transition={{ duration: 0.5, delay: 0.05 }} />
        <motion.rect x="38" y="46" width="42" height="30" rx="6" fill={faint} animate={{ y: active ? 46 : 44 }} transition={{ duration: 0.5, delay: 0.1 }} />
        <motion.circle cx="96" cy="45" r="14" fill="none" stroke={stroke} strokeWidth="2" animate={{ r: active ? 16 : 13 }} transition={{ duration: 0.5 }} />
        <circle cx="96" cy="45" r="4" fill={stroke} />
      </svg>);

  }

  // growth — expanding network
  return (
    <svg viewBox="0 0 120 90" className="h-full w-full" aria-hidden="true">
      <circle cx="30" cy="45" r="6" fill={stroke} />
      {[
      [70, 20],
      [78, 46],
      [66, 72]].
      map(([x, y], i) =>
      <g key={i}>
          <motion.line
          x1="30"
          y1="45"
          x2={x}
          y2={y}
          stroke={faint}
          strokeWidth="1.6"
          animate={{ opacity: active ? 1 : 0.5 }}
          transition={{ delay: i * 0.06 }} />
        
          <motion.circle
          cx={x}
          cy={y}
          r="4.5"
          fill={active ? stroke : faint}
          animate={{ scale: active ? 1 : 0.7 }}
          transition={{ duration: 0.4, delay: 0.1 + i * 0.06 }} />
        
          {[0, 1].map((j) =>
        <motion.circle
          key={j}
          cx={x + 24}
          cy={y - 10 + j * 20}
          r="2.6"
          fill={faint}
          animate={{ opacity: active ? 1 : 0, scale: active ? 1 : 0.4 }}
          transition={{ duration: 0.4, delay: 0.2 + i * 0.05 + j * 0.05 }} />

        )}
        </g>
      )}
    </svg>);

}