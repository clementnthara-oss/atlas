import React from 'react';
import { motion } from 'framer-motion';
import { ArrowRightIcon, ArrowDownIcon } from 'lucide-react';

interface FlowStripProps {
  steps: string[];
  accent: string;
  tone?: 'dark' | 'light';
}

/** Horizontal on desktop, vertical on mobile — never a shrunken diagram. */
export function FlowStrip({ steps, accent, tone = 'dark' }: FlowStripProps) {
  const isDark = tone === 'dark';
  return (
    <ol className="flex flex-col gap-2 sm:flex-row sm:flex-wrap sm:items-center">
      {steps.map((step, i) =>
      <li key={step} className="flex items-center gap-2">
          <motion.span
          initial={{ opacity: 0, y: 6 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.35, delay: i * 0.06, ease: [0.22, 1, 0.36, 1] }}
          className="rounded-control border px-3 py-2 text-[12px] font-medium"
          style={{
            borderColor: i === steps.length - 1 ? accent : isDark ? 'rgba(255,255,255,0.14)' : 'rgba(8,9,11,0.12)',
            background: i === steps.length - 1 ? accent : isDark ? 'rgba(255,255,255,0.04)' : '#FFFFFF',
            color: i === steps.length - 1 ? '#08090B' : isDark ? 'rgba(255,255,255,0.82)' : '#08090B'
          }}>
          
            {step}
          </motion.span>
          {i < steps.length - 1 &&
        <>
              <ArrowRightIcon
            className="hidden h-3.5 w-3.5 shrink-0 sm:block"
            style={{ color: isDark ? 'rgba(255,255,255,0.3)' : 'rgba(8,9,11,0.3)' }}
            aria-hidden="true" />
          
              <ArrowDownIcon
            className="h-3.5 w-3.5 shrink-0 sm:hidden"
            style={{ color: isDark ? 'rgba(255,255,255,0.3)' : 'rgba(8,9,11,0.3)' }}
            aria-hidden="true" />
          
            </>
        }
        </li>
      )}
    </ol>);

}