import React from 'react';
import { AnimatePresence, motion } from 'framer-motion';

interface BrowserFrameProps {
  surface: 'Website' | 'Web app' | 'Dashboard' | 'Customer portal';
}

const bar = (w: string, c = 'rgba(255,255,255,0.14)') => ({ width: w, background: c });

/** A coded interface rendering — real UI structure rather than a stock screenshot. */
export function BrowserFrame({ surface }: BrowserFrameProps) {
  return (
    <div className="overflow-hidden rounded-feature border border-ink/12 bg-ink shadow-[0_40px_90px_-50px_rgba(8,9,11,0.7)]">
      <div className="flex items-center gap-2 border-b border-white/10 px-4 py-3">
        <span className="flex gap-1.5" aria-hidden="true">
          {['#FF4FD8', '#FF8A3D', '#B7FF3C'].map((c) =>
          <span key={c} className="h-2.5 w-2.5 rounded-full" style={{ background: c, opacity: 0.7 }} />
          )}
        </span>
        <span className="ml-3 flex-1 rounded-full bg-white/[0.06] px-3 py-1 text-[10px] text-white/40">
          atlasintelligence.build / {surface.toLowerCase().replace(' ', '-')}
        </span>
      </div>

      <div className="relative aspect-[16/11] w-full">
        <AnimatePresence mode="wait">
          <motion.div
            key={surface}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }}
            transition={{ duration: 0.35, ease: [0.22, 1, 0.36, 1] }}
            className="absolute inset-0 p-5">
            
            {surface === 'Website' &&
            <div className="flex h-full flex-col gap-4">
                <div className="h-2 rounded-full" style={bar('35%', '#B7FF3C')} />
                <div className="h-6 rounded" style={bar('80%', 'rgba(255,255,255,0.22)')} />
                <div className="h-6 rounded" style={bar('55%', 'rgba(255,255,255,0.14)')} />
                <div className="mt-2 flex gap-2">
                  <div className="h-8 w-28 rounded" style={{ background: '#2457FF' }} />
                  <div className="h-8 w-28 rounded border border-white/20" />
                </div>
                <div className="mt-auto grid grid-cols-3 gap-3">
                  {[0, 1, 2].map((i) =>
                <div key={i} className="h-20 rounded-lg border border-white/10 bg-white/[0.04]" />
                )}
                </div>
              </div>
            }

            {surface === 'Web app' &&
            <div className="flex h-full gap-4">
                <div className="hidden w-28 flex-col gap-2 border-r border-white/10 pr-3 sm:flex">
                  {[0, 1, 2, 3, 4].map((i) =>
                <div
                  key={i}
                  className="h-6 rounded"
                  style={{ background: i === 1 ? 'rgba(36,87,255,0.35)' : 'rgba(255,255,255,0.06)' }} />

                )}
                </div>
                <div className="flex flex-1 flex-col gap-3">
                  <div className="h-4 w-40 rounded" style={bar('', 'rgba(255,255,255,0.2)')} />
                  <div className="grid grid-cols-2 gap-3">
                    {[0, 1, 2, 3].map((i) =>
                  <div key={i} className="h-16 rounded-lg border border-white/10 bg-white/[0.04] p-3">
                        <div className="h-1.5 w-10 rounded-full bg-white/20" />
                        <div className="mt-2 h-3 w-16 rounded" style={{ background: i === 0 ? '#25D9FF' : 'rgba(255,255,255,0.14)' }} />
                      </div>
                  )}
                  </div>
                  <div className="mt-auto space-y-2">
                    {[0, 1, 2].map((i) =>
                  <div key={i} className="flex items-center gap-3">
                        <div className="h-2 w-2 rounded-full bg-white/25" />
                        <div className="h-2 flex-1 rounded-full bg-white/10" />
                        <div className="h-2 w-10 rounded-full bg-white/20" />
                      </div>
                  )}
                  </div>
                </div>
              </div>
            }

            {surface === 'Dashboard' &&
            <div className="flex h-full flex-col gap-3">
                <div className="grid grid-cols-4 gap-3">
                  {['#2457FF', '#B7FF3C', '#FF3CAC', '#FF8A3D'].map((c) =>
                <div key={c} className="rounded-lg border border-white/10 bg-white/[0.04] p-2.5">
                      <div className="h-1.5 w-8 rounded-full bg-white/20" />
                      <div className="mt-2 h-2.5 w-12 rounded" style={{ background: c }} />
                    </div>
                )}
                </div>
                <div className="relative flex-1 rounded-lg border border-white/10 bg-white/[0.03] p-3">
                  <svg viewBox="0 0 300 100" className="h-full w-full" aria-hidden="true">
                    <motion.path
                    d="M0 80 L40 66 L80 72 L120 48 L160 55 L200 30 L240 38 L300 12"
                    fill="none"
                    stroke="#25D9FF"
                    strokeWidth="2"
                    initial={{ pathLength: 0 }}
                    animate={{ pathLength: 1 }}
                    transition={{ duration: 1.2, ease: [0.22, 1, 0.36, 1] }} />
                  
                    <motion.path
                    d="M0 90 L40 84 L80 86 L120 74 L160 78 L200 62 L240 66 L300 52"
                    fill="none"
                    stroke="rgba(255,255,255,0.18)"
                    strokeWidth="2"
                    initial={{ pathLength: 0 }}
                    animate={{ pathLength: 1 }}
                    transition={{ duration: 1.2, delay: 0.15 }} />
                  
                  </svg>
                </div>
              </div>
            }

            {surface === 'Customer portal' &&
            <div className="flex h-full flex-col gap-3">
                <div className="flex items-center gap-3">
                  <div className="h-9 w-9 rounded-full" style={{ background: '#FF3CAC' }} />
                  <div>
                    <div className="h-2.5 w-24 rounded-full bg-white/25" />
                    <div className="mt-1.5 h-2 w-16 rounded-full bg-white/12" />
                  </div>
                </div>
                <div className="rounded-lg border border-white/10 bg-white/[0.04] p-3">
                  <div className="h-1.5 w-20 rounded-full bg-white/20" />
                  <div className="mt-3 flex gap-2">
                    {['#B7FF3C', 'rgba(255,255,255,0.14)', 'rgba(255,255,255,0.1)'].map((c, i) =>
                  <div key={i} className="h-1.5 flex-1 rounded-full" style={{ background: c }} />
                  )}
                  </div>
                </div>
                <div className="mt-auto grid grid-cols-2 gap-3">
                  {[0, 1].map((i) =>
                <div key={i} className="h-24 rounded-lg border border-white/10 bg-white/[0.03] p-3">
                      <div className="h-1.5 w-12 rounded-full bg-white/20" />
                      <div className="mt-3 h-1.5 w-full rounded-full bg-white/10" />
                      <div className="mt-2 h-1.5 w-2/3 rounded-full bg-white/10" />
                    </div>
                )}
                </div>
              </div>
            }
          </motion.div>
        </AnimatePresence>
      </div>
    </div>);

}