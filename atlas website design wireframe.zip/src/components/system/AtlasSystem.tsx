import React from 'react';
import { motion, useReducedMotion } from 'framer-motion';
import { outcomes } from '../../data/outcomes';

interface AtlasSystemProps {
  active: number;
  onSelect: (index: number) => void;
}

const positions = [
{ x: 50, y: 12, label: 'REVENUE' },
{ x: 88, y: 50, label: 'EFFICIENCY' },
{ x: 50, y: 88, label: 'TRUST' },
{ x: 12, y: 50, label: 'GROWTH' }];


const fragments = [
['Enquiry', 'Qualified', 'Booked'],
['Trigger', 'Automated', 'Reported'],
['Identity', 'Experience', 'Confidence'],
['Platform', 'Capability', 'Market']];


/** The hero's live business-intelligence system: an Atlas core with four outcome nodes. */
export function AtlasSystem({ active, onSelect }: AtlasSystemProps) {
  const reduce = useReducedMotion();
  const current = outcomes[active];

  return (
    <div
      className="relative overflow-hidden rounded-hero border border-ink/10 bg-ink p-5 sm:p-7"
      style={{ boxShadow: '0 30px 80px -40px rgba(8,9,11,0.55)' }}>
      
      <div className="pointer-events-none absolute inset-0 dot-grid opacity-40" aria-hidden="true" />
      <motion.div
        className="pointer-events-none absolute inset-0"
        animate={{ opacity: 0.35 }}
        style={{
          background: `radial-gradient(60% 55% at 50% 50%, ${current.accent}55 0%, transparent 70%)`,
          transition: 'background 700ms cubic-bezier(0.22,1,0.36,1)'
        }}
        aria-hidden="true" />
      

      <div className="relative flex items-center justify-between">
        <span className="label text-white/45">Atlas system &middot; live view</span>
        <span className="label" style={{ color: current.accent }}>
          {current.title}
        </span>
      </div>

      <div className="relative mt-4 aspect-square w-full sm:aspect-[4/3.4]">
        <svg viewBox="0 0 100 100" className="absolute inset-0 h-full w-full" aria-hidden="true">
          {positions.map((p, i) =>
          <line
            key={p.label}
            x1="50"
            y1="50"
            x2={p.x}
            y2={p.y}
            stroke={i === active ? outcomes[i].accent : 'rgba(255,255,255,0.16)'}
            strokeWidth={i === active ? 0.7 : 0.4}
            className={i === active && !reduce ? 'dash-flow' : ''} />

          )}
          <polygon
            points={positions.map((p) => `${p.x},${p.y}`).join(' ')}
            fill="none"
            stroke="rgba(255,255,255,0.09)"
            strokeWidth="0.35" />
          
          <circle cx="50" cy="50" r="13" fill="none" stroke="rgba(255,255,255,0.12)" strokeWidth="0.35" />
        </svg>

        {/* Core */}
        <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2">
          <div className="relative flex h-20 w-20 items-center justify-center rounded-full border border-white/20 bg-white/[0.06] backdrop-blur-sm sm:h-24 sm:w-24">
            {!reduce &&
            <motion.span
              className="absolute inset-0 rounded-full"
              style={{ boxShadow: `0 0 0 0 ${current.accent}` }}
              animate={{ boxShadow: [`0 0 0 0 ${current.accent}66`, `0 0 0 18px ${current.accent}00`] }}
              transition={{ duration: 2.2, repeat: Infinity, ease: 'easeOut' }} />

            }
            <span className="text-center text-[11px] font-semibold leading-tight tracking-tight text-white">
              ATLAS
              <span className="mt-0.5 block text-[9px] font-normal text-white/50">core</span>
            </span>
          </div>
        </div>

        {/* Outcome nodes */}
        {positions.map((p, i) => {
          const o = outcomes[i];
          const isActive = i === active;
          return (
            <button
              key={p.label}
              type="button"
              onClick={() => onSelect(i)}
              aria-pressed={isActive}
              className="absolute -translate-x-1/2 -translate-y-1/2 rounded-full transition-transform duration-300 ease-atlas hover:scale-105"
              style={{ left: `${p.x}%`, top: `${p.y}%` }}>
              
              <span
                className="flex items-center gap-2 rounded-full border px-3 py-1.5 text-[11px] font-medium tracking-tight transition-colors duration-300"
                style={{
                  borderColor: isActive ? o.accent : 'rgba(255,255,255,0.18)',
                  background: isActive ? o.accent : 'rgba(255,255,255,0.04)',
                  color: isActive ? o.ink : 'rgba(255,255,255,0.72)'
                }}>
                
                <span
                  className="h-1.5 w-1.5 rounded-full"
                  style={{ background: isActive ? o.ink : o.accent }} />
                
                {o.title}
              </span>
            </button>);

        })}
      </div>

      {/* Interface fragments */}
      <div className="relative mt-4 grid grid-cols-3 gap-2">
        {fragments[active].map((f, i) =>
        <motion.div
          key={`${active}-${f}`}
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, delay: i * 0.07, ease: [0.22, 1, 0.36, 1] }}
          className="rounded-control border border-white/10 bg-white/[0.04] px-3 py-2.5">
          
            <span className="block text-[10px] uppercase tracking-[0.12em] text-white/40">
              0{i + 1}
            </span>
            <span className="mt-1 block text-[12px] text-white/85">{f}</span>
          </motion.div>
        )}
      </div>

      <p className="relative mt-4 text-[12px] leading-relaxed text-white/50">{current.line}</p>
    </div>);

}