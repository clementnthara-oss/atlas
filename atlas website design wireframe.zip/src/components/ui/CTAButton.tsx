import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowRightIcon } from 'lucide-react';

type Variant = 'primary' | 'secondary' | 'onDark';
type Size = 'sm' | 'md' | 'lg';

interface CTAButtonProps {
  to: string;
  children: React.ReactNode;
  variant?: Variant;
  size?: Size;
  className?: string;
  showArrow?: boolean;
}

const sizes: Record<Size, string> = {
  sm: 'h-9 px-4 text-[13px]',
  md: 'h-11 px-5 text-sm',
  lg: 'h-13 px-7 text-[15px]'
};

const variants: Record<Variant, string> = {
  primary:
  'bg-ink text-white hover:bg-atlas active:translate-y-px shadow-[0_1px_0_rgba(255,255,255,0.12)_inset]',
  secondary:
  'bg-transparent text-ink border border-ink/20 hover:border-ink hover:bg-ink/[0.04] active:translate-y-px',
  onDark:
  'bg-white text-ink hover:bg-neon active:translate-y-px'
};

export function CTAButton({
  to,
  children,
  variant = 'primary',
  size = 'md',
  className = '',
  showArrow = true
}: CTAButtonProps) {
  const isHash = to.startsWith('#');
  const classes = `group inline-flex items-center justify-center gap-2 rounded-control font-medium tracking-[-0.01em] transition-all duration-200 ease-atlas ${sizes[size]} ${variants[variant]} ${className}`;

  const content =
  <>
      {children}
      {showArrow &&
    <ArrowRightIcon
      className="h-4 w-4 transition-transform duration-200 ease-atlas group-hover:translate-x-1"
      aria-hidden="true" />

    }
    </>;


  if (isHash) {
    return (
      <a href={to} className={classes}>
        {content}
      </a>);

  }

  return (
    <Link to={to} className={classes}>
      {content}
    </Link>);

}