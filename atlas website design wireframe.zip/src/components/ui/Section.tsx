import React from 'react';

interface SectionProps {
  id?: string;
  children: React.ReactNode;
  className?: string;
  tone?: 'light' | 'soft' | 'dark';
  bleed?: boolean;
  label?: string;
  as?: 'section' | 'div';
}

const tones = {
  light: 'bg-base text-ink',
  soft: 'bg-base-soft text-ink',
  dark: 'bg-ink text-white'
};

export function Section({
  id,
  children,
  className = '',
  tone = 'light',
  bleed = false,
  label,
  as: Tag = 'section'
}: SectionProps) {
  return (
    <Tag id={id} className={`relative w-full ${tones[tone]} ${className}`}>
      {label &&
      <div className="mx-auto max-w-site px-5 pt-16 sm:px-8 md:pt-24">
          <SectionLabel tone={tone}>{label}</SectionLabel>
        </div>
      }
      {bleed ? children : <div className="mx-auto max-w-site px-5 sm:px-8">{children}</div>}
    </Tag>);

}

export function SectionLabel({
  children,
  tone = 'light',
  accent




}: {children: React.ReactNode;tone?: 'light' | 'soft' | 'dark';accent?: string;}) {
  return (
    <div className="flex items-center gap-3">
      <span
        className="h-1.5 w-1.5 rounded-full"
        style={{ background: accent || (tone === 'dark' ? '#B7FF3C' : '#2457FF') }}
        aria-hidden="true" />
      
      <span className={`label ${tone === 'dark' ? 'text-white/55' : 'text-ink-muted'}`}>{children}</span>
    </div>);

}

export function SectionHeading({
  title,
  lede,
  tone = 'light',
  align = 'left',
  className = '',
  as = 'h2'







}: {title: React.ReactNode;lede?: React.ReactNode;tone?: 'light' | 'soft' | 'dark';align?: 'left' | 'center';className?: string;as?: 'h1' | 'h2' | 'h3';}) {
  const Tag = as;
  return (
    <div className={`${align === 'center' ? 'mx-auto max-w-3xl text-center' : 'max-w-3xl'} ${className}`}>
      <Tag className={`text-h2 font-semibold ${tone === 'dark' ? 'text-white' : 'text-ink'}`}>{title}</Tag>
      {lede &&
      <p className={`mt-5 text-bodylg ${tone === 'dark' ? 'text-white/65' : 'text-ink-muted'}`}>{lede}</p>
      }
    </div>);

}