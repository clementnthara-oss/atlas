import React from 'react';
import { Link } from 'react-router-dom';
import { Logo } from './Logo';
import { services } from '../data/services';

const columns = [
{
  title: 'Services',
  links: services.map((s) => ({ label: s.name, to: `/services/${s.slug}` }))
},
{
  title: 'Company',
  links: [
  { label: 'Work', to: '/work' },
  { label: 'Approach', to: '/approach' },
  { label: 'Product Studio', to: '/product-studio' },
  { label: 'About', to: '/about' },
  { label: 'Insights', to: '/insights' },
  { label: 'Book a Call', to: '/contact' }]

}];


export function Footer() {
  return (
    <footer className="w-full bg-ink text-white">
      <div className="mx-auto max-w-site px-5 py-16 sm:px-8 md:py-20">
        <div className="grid gap-12 md:grid-cols-[1.4fr_1fr_1fr]">
          <div>
            <Logo tone="light" />
            <p className="mt-5 max-w-xs text-sm leading-relaxed text-white/55">
              An AI agency with global reach. We understand the business, find what matters, and build what
              changes it.
            </p>
            <div className="mt-6 flex flex-wrap gap-2">
              {['Client Services', 'Product Studio'].map((arm) =>
              <span
                key={arm}
                className="rounded-full border border-white/15 px-3 py-1 text-xs text-white/70">
                
                  {arm}
                </span>
              )}
            </div>
          </div>

          {columns.map((col) =>
          <nav key={col.title} aria-label={col.title}>
              <h2 className="label text-white/40">{col.title}</h2>
              <ul className="mt-5 space-y-3">
                {col.links.map((l) =>
              <li key={l.to}>
                    <Link
                  to={l.to}
                  className="text-sm text-white/70 transition-colors hover:text-neon">
                  
                      {l.label}
                    </Link>
                  </li>
              )}
              </ul>
            </nav>
          )}
        </div>

        <div className="mt-16 flex flex-col gap-4 border-t border-white/10 pt-8 text-xs text-white/40 sm:flex-row sm:items-center sm:justify-between">
          <p>&copy; {new Date().getFullYear()} Atlas Intelligence Group. Global reach.</p>
          <p className="max-w-md">
            No fabricated clients, metrics or testimonials appear on this site. Unmeasured figures are labelled
            as such.
          </p>
        </div>
      </div>
    </footer>);

}