import React, { useEffect, useState } from 'react';
import { Link, NavLink, useLocation } from 'react-router-dom';
import { AnimatePresence, motion } from 'framer-motion';
import { MenuIcon, XIcon } from 'lucide-react';
import { Logo } from './Logo';
import { CTAButton } from './ui/CTAButton';

const nav = [
{ label: 'Work', to: '/work' },
{ label: 'Services', to: '/services' },
{ label: 'Product Studio', to: '/product-studio' },
{ label: 'Approach', to: '/approach' },
{ label: 'About', to: '/about' },
{ label: 'Insights', to: '/insights' }];


export function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);
  const location = useLocation();

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 12);
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  useEffect(() => {
    setOpen(false);
  }, [location.pathname]);

  useEffect(() => {
    document.body.style.overflow = open ? 'hidden' : '';
    return () => {
      document.body.style.overflow = '';
    };
  }, [open]);

  return (
    <>
      <a
        href="#main"
        className="sr-only focus:not-sr-only focus:fixed focus:left-4 focus:top-4 focus:z-[60] focus:rounded-control focus:bg-ink focus:px-4 focus:py-2 focus:text-sm focus:text-white">
        
        Skip to content
      </a>
      <header
        className={`fixed inset-x-0 top-0 z-50 transition-all duration-300 ease-atlas ${
        scrolled ? 'border-b border-ink/10 bg-base/85 backdrop-blur-xl' : 'border-b border-transparent'}`
        }>
        
        <nav
          className="mx-auto flex h-16 max-w-site items-center justify-between px-5 sm:px-8"
          aria-label="Primary">
          
          <Link to="/" className="shrink-0" aria-label="Atlas Intelligence Group — home">
            <Logo />
          </Link>

          <ul className="hidden items-center gap-1 lg:flex">
            {nav.map((item) =>
            <li key={item.to}>
                <NavLink
                to={item.to}
                className={({ isActive }) =>
                `relative rounded-control px-3 py-2 text-sm transition-colors duration-200 ${
                isActive ? 'text-ink' : 'text-ink-muted hover:text-ink'}`

                }>
                
                  {({ isActive }) =>
                <>
                      {item.label}
                      {isActive &&
                  <motion.span
                    layoutId="nav-underline"
                    className="absolute inset-x-3 -bottom-0.5 h-px bg-atlas" />

                  }
                    </>
                }
                </NavLink>
              </li>
            )}
          </ul>

          <div className="hidden items-center gap-3 lg:flex">
            <CTAButton to="/contact" size="sm">
              Book a Call
            </CTAButton>
          </div>

          <div className="flex items-center gap-2 lg:hidden">
            <CTAButton to="/contact" size="sm" showArrow={false}>
              Book a Call
            </CTAButton>
            <button
              type="button"
              onClick={() => setOpen((v) => !v)}
              aria-expanded={open}
              aria-controls="mobile-nav"
              aria-label={open ? 'Close menu' : 'Open menu'}
              className="flex h-9 w-9 items-center justify-center rounded-control border border-ink/15 text-ink">
              
              {open ? <XIcon className="h-4 w-4" /> : <MenuIcon className="h-4 w-4" />}
            </button>
          </div>
        </nav>
      </header>

      <AnimatePresence>
        {open &&
        <motion.div
          id="mobile-nav"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.2 }}
          className="fixed inset-0 z-40 bg-base pt-16 lg:hidden">
          
            <ul className="mx-auto max-w-site px-5 py-6 sm:px-8">
              {nav.map((item, i) =>
            <motion.li
              key={item.to}
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.04 * i, duration: 0.3, ease: [0.22, 1, 0.36, 1] }}
              className="border-b border-ink/10">
              
                  <Link to={item.to} className="block py-4 text-h3 font-semibold tracking-tight">
                    {item.label}
                  </Link>
                </motion.li>
            )}
              <li className="pt-8">
                <CTAButton to="/contact" size="lg" className="w-full">
                  Book a Call
                </CTAButton>
              </li>
              <li className="pt-3">
                <CTAButton to="/work" size="lg" variant="secondary" className="w-full">
                  See What&rsquo;s Possible
                </CTAButton>
              </li>
            </ul>
          </motion.div>
        }
      </AnimatePresence>
    </>);

}