import React from 'react';
import { Link, useParams } from 'react-router-dom';
import { ArrowLeftIcon } from 'lucide-react';
import { getCaseStudy, caseStudies } from '../data/caseStudies';
import { services } from '../data/services';
import { usePageMeta } from '../hooks/usePageMeta';
import { CTAButton } from '../components/ui/CTAButton';
import { NotFound } from './NotFound';

export function CaseStudyPage() {
  const { slug } = useParams<{slug: string;}>();
  const study = slug ? getCaseStudy(slug) : undefined;

  usePageMeta({
    title: study ? `${study.summary.slice(0, 60)}… — Atlas Intelligence Group` : 'Case study — AIG',
    description: study?.summary ?? 'Case study',
    path: `/work/${slug ?? ''}`,
    type: 'article'
  });

  if (!study) return <NotFound />;

  const sections: [string, string][] = [
  ['Context', `${study.industry}. ${study.client}.`],
  ['Problem', study.problem],
  ['Opportunity', study.opportunity],
  ['Discovery', study.discovery],
  ['Strategy', study.strategy],
  ['Design', study.design],
  ['Engineering', study.engineering],
  ['AI', study.ai],
  ['Automation', study.automation],
  ['Outcome', study.outcome],
  ['Reflection', study.reflection]];


  const others = caseStudies.filter((c) => c.slug !== study.slug);

  return (
    <article>
      <header
        className="relative w-full overflow-hidden py-16 md:py-24"
        style={{ background: `linear-gradient(150deg, ${study.accent} 0%, #08090B 65%)` }}>
        
        <div className="pointer-events-none absolute inset-0 dot-grid opacity-25" aria-hidden="true" />
        <div className="relative mx-auto max-w-site px-5 sm:px-8">
          <Link
            to="/work"
            className="inline-flex items-center gap-2 text-[13px] text-white/70 transition-colors hover:text-white">
            
            <ArrowLeftIcon className="h-3.5 w-3.5" aria-hidden="true" />
            All work
          </Link>
          <div className="mt-8 flex flex-wrap items-center gap-3">
            <span className="rounded-full bg-white/15 px-3 py-1 text-[11px] text-white">{study.status}</span>
            <span className="text-[11px] text-white/60">{study.industry}</span>
          </div>
          <h1 className="mt-6 max-w-4xl text-h1 font-semibold text-white">{study.summary}</h1>
          <p className="mt-6 max-w-2xl text-sm text-white/70">
            {study.client} — a documented pattern, published so the thinking is visible. No client name,
            number or quote is invented on this page.
          </p>
        </div>
      </header>

      <div className="mx-auto grid max-w-site gap-12 px-5 py-16 sm:px-8 md:py-24 lg:grid-cols-[1fr_300px] lg:gap-16">
        <div className="space-y-12">
          {sections.map(([title, body], i) =>
          <section key={title} className="grid gap-3 border-t border-ink/10 pt-8 md:grid-cols-[160px_1fr] md:gap-10">
              <h2 className="label pt-1 text-ink-faint">
                {String(i + 1).padStart(2, '0')} &nbsp; {title}
              </h2>
              <p className="text-bodylg leading-relaxed text-ink">{body}</p>
            </section>
          )}

          <section className="border-t border-ink/10 pt-8">
            <h2 className="label text-ink-faint">Evidence</h2>
            <div className="mt-6 overflow-hidden rounded-feature border border-ink/10">
              <table className="w-full text-left text-[13px]">
                <caption className="sr-only">Metrics for this engagement pattern</caption>
                <thead className="bg-base-soft">
                  <tr>
                    {['Metric', 'Before', 'After', 'Change', 'Source', 'Verified'].map((h) =>
                    <th key={h} scope="col" className="px-4 py-3 font-medium text-ink-muted">
                        {h}
                      </th>
                    )}
                  </tr>
                </thead>
                <tbody className="divide-y divide-ink/8 bg-white">
                  {study.metrics.map((m) =>
                  <tr key={m.name}>
                      <th scope="row" className="px-4 py-3.5 text-left font-medium text-ink">
                        {m.name}
                        {m.unit && <span className="ml-1.5 text-ink-faint">({m.unit})</span>}
                      </th>
                      <td className="px-4 py-3.5 text-ink-faint">{m.before ?? '—'}</td>
                      <td className="px-4 py-3.5 text-ink-faint">{m.after ?? '—'}</td>
                      <td className="px-4 py-3.5 text-ink-faint">{m.change ?? 'Not yet measured'}</td>
                      <td className="px-4 py-3.5 text-ink-faint">{m.source ?? '—'}</td>
                      <td className="px-4 py-3.5">
                        <span className="rounded-full border border-ink/12 px-2 py-0.5 text-[11px] text-ink-muted">
                          {m.verified ? 'Verified' : 'No'}
                        </span>
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </section>
        </div>

        <aside className="space-y-6 lg:sticky lg:top-24 lg:self-start">
          <div className="rounded-feature border border-ink/10 bg-white p-6">
            <span className="label text-ink-faint">Services</span>
            <ul className="mt-4 space-y-2">
              {study.services.map((s) => {
                const service = services.find((x) => x.slug === s);
                if (!service) return null;
                return (
                  <li key={s}>
                    <Link
                      to={`/services/${service.slug}`}
                      className="flex items-center gap-2.5 text-[13px] text-ink transition-colors hover:text-atlas">
                      
                      <span className="h-1.5 w-1.5 rounded-full" style={{ background: service.accent }} />
                      {service.name}
                    </Link>
                  </li>);

              })}
            </ul>
            <span className="mt-6 block label text-ink-faint">Technology</span>
            <ul className="mt-3 flex flex-wrap gap-1.5">
              {study.technology.map((t) =>
              <li key={t} className="rounded-full bg-base-soft px-2.5 py-1 text-[11px] text-ink-muted">
                  {t}
                </li>
              )}
            </ul>
          </div>

          <div className="rounded-feature border border-ink/10 bg-ink p-6 text-white">
            <p className="text-sm text-white/70">Recognise any of this in your own business?</p>
            <div className="mt-5">
              <CTAButton to="/contact" variant="onDark" size="sm">
                Book a Call
              </CTAButton>
            </div>
          </div>
        </aside>
      </div>

      <section className="border-t border-ink/10 bg-base-soft py-16" aria-label="More work">
        <div className="mx-auto max-w-site px-5 sm:px-8">
          <span className="label text-ink-faint">Next</span>
          <ul className="mt-6 grid gap-4 md:grid-cols-2">
            {others.map((o) =>
            <li key={o.slug}>
                <Link
                to={`/work/${o.slug}`}
                className="group block rounded-feature border border-ink/10 bg-white p-6 transition-colors hover:border-ink/30">
                
                  <span className="label" style={{ color: o.accent }}>
                    {o.industry}
                  </span>
                  <p className="mt-3 text-h4 font-semibold text-ink group-hover:text-atlas">{o.summary}</p>
                </Link>
              </li>
            )}
          </ul>
        </div>
      </section>
    </article>);

}