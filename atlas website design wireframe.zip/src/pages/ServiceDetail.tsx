import React from 'react';
import { Link, useParams } from 'react-router-dom';
import { getService, services } from '../data/services';
import { outcomes } from '../data/outcomes';
import { caseStudies } from '../data/caseStudies';
import { PageHeader } from '../components/PageHeader';
import { FlowStrip } from '../components/system/FlowStrip';
import { CTAButton } from '../components/ui/CTAButton';
import { usePageMeta } from '../hooks/usePageMeta';
import { NotFound } from './NotFound';

export function ServiceDetail() {
  const { slug } = useParams<{slug: string;}>();
  const service = slug ? getService(slug) : undefined;

  usePageMeta({
    title: service ? `${service.name} — Atlas Intelligence Group` : 'Service — AIG',
    description: service?.description ?? 'Service',
    path: `/services/${slug ?? ''}`
  });

  if (!service) return <NotFound />;

  const related = caseStudies.filter((c) => c.services.includes(service.slug));
  const others = services.filter((s) => s.slug !== service.slug);

  return (
    <>
      <PageHeader
        label={`Services / ${service.name}`}
        title={service.name}
        lede={service.description}
        tone="dark"
        accent={service.accent}
        gradient={`radial-gradient(75% 70% at 12% 0%, ${service.accent}44 0%, transparent 62%)`}>
        
        <div className="flex flex-wrap gap-3">
          <CTAButton to="/contact" variant="onDark">
            Book a Call
          </CTAButton>
          <Link
            to="/work"
            className="inline-flex h-11 items-center rounded-control border border-white/30 px-5 text-sm text-white transition-colors hover:bg-white/10">
            
            See What&rsquo;s Possible
          </Link>
        </div>
      </PageHeader>

      <section className="w-full py-16 md:py-24">
        <div className="mx-auto max-w-site px-5 sm:px-8">
          <div className="rounded-feature border border-ink/10 bg-white p-7 sm:p-10">
            <span className="label text-ink-faint">How the system runs</span>
            <div className="mt-6">
              <FlowStrip steps={service.flow} accent={service.accent} tone="light" />
            </div>
          </div>

          <div className="mt-4 grid gap-4 lg:grid-cols-3">
            <div className="rounded-feature border border-ink/10 bg-white p-7">
              <span className="label text-ink-faint">Capabilities</span>
              <ul className="mt-5 space-y-2.5">
                {service.capabilities.map((c) =>
                <li key={c} className="flex items-start gap-2.5 text-[14px] text-ink">
                    <span
                    className="mt-2 h-1.5 w-1.5 shrink-0 rounded-full"
                    style={{ background: service.accent }}
                    aria-hidden="true" />
                  
                    {c}
                  </li>
                )}
              </ul>
            </div>

            <div className="rounded-feature border border-ink/10 bg-white p-7">
              <span className="label text-ink-faint">Outcomes it moves</span>
              <ul className="mt-5 space-y-4">
                {service.outcomes.map((k) => {
                  const o = outcomes.find((x) => x.key === k)!;
                  return (
                    <li key={k}>
                      <span className="flex items-center gap-2 text-[15px] font-medium text-ink">
                        <span className="h-2 w-2 rounded-full" style={{ background: o.accent }} />
                        {o.title}
                      </span>
                      <p className="mt-1.5 text-[13px] text-ink-muted">{o.line}</p>
                    </li>);

                })}
              </ul>
            </div>

            <div className="rounded-feature border border-ink/10 bg-base-soft p-7">
              <span className="label text-ink-faint">What we measure</span>
              <dl className="mt-5 space-y-3">
                {service.metricCategories.map((m) =>
                <div key={m} className="flex items-baseline justify-between gap-4 border-b border-ink/8 pb-2.5">
                    <dt className="text-[13px] text-ink">{m}</dt>
                    <dd className="text-[11px] text-ink-faint">Not yet measured</dd>
                  </div>
                )}
              </dl>
              <p className="mt-5 text-[12px] leading-relaxed text-ink-faint">
                Baselines are captured at the start of an engagement so the change is measurable rather than
                asserted.
              </p>
            </div>
          </div>

          {related.length > 0 &&
          <div className="mt-12">
              <span className="label text-ink-faint">Where this shows up</span>
              <ul className="mt-5 grid gap-4 md:grid-cols-3">
                {related.map((c) =>
              <li key={c.slug}>
                    <Link
                  to={`/work/${c.slug}`}
                  className="group block h-full rounded-feature border border-ink/10 bg-white p-6 transition-colors hover:border-ink/30">
                  
                      <span className="label" style={{ color: c.accent }}>
                        {c.industry}
                      </span>
                      <p className="mt-3 text-[15px] font-medium text-ink group-hover:text-atlas">{c.summary}</p>
                    </Link>
                  </li>
              )}
              </ul>
            </div>
          }

          <div className="mt-12 border-t border-ink/10 pt-8">
            <span className="label text-ink-faint">Other services</span>
            <ul className="mt-5 flex flex-wrap gap-2">
              {others.map((s) =>
              <li key={s.slug}>
                  <Link
                  to={`/services/${s.slug}`}
                  className="inline-flex items-center gap-2 rounded-control border border-ink/12 bg-white px-3.5 py-2 text-[13px] text-ink-muted transition-colors hover:border-ink/40 hover:text-ink">
                  
                    <span className="h-1.5 w-1.5 rounded-full" style={{ background: s.accent }} />
                    {s.name}
                  </Link>
                </li>
              )}
            </ul>
          </div>
        </div>
      </section>
    </>);

}