import React from 'react';
import { PageHeader } from '../components/PageHeader';
import { Method } from '../components/home/Method';
import { AIAndHuman } from '../components/home/AIAndHuman';
import { Beliefs } from '../components/home/Beliefs';
import { Reveal } from '../components/ui/Reveal';
import { CTAButton } from '../components/ui/CTAButton';
import { usePageMeta } from '../hooks/usePageMeta';

const promises = [
'Every engagement starts with real discovery before any design or code happens.',
'Design and engineering happen together, with regular check-ins, so delivery is never a surprise.',
'We handle deployment and testing, so what ships is stable from day one.',
'We stay involved after launch — support and iteration as a partner, not a handover.'];


export function Approach() {
  usePageMeta({
    title: 'Approach — Atlas Intelligence Group',
    description:
    'Understand, diagnose, prioritize, design, build, deploy, evolve. How AIG runs an engagement, and what we hold to along the way.',
    path: '/approach'
  });

  return (
    <>
      <PageHeader
        label="Approach"
        title="Understand the business. Find what matters. Build what changes it."
        lede="We don't start with 'what AI tool should we use?'. We start with 'what is the business trying to accomplish?'" />
      

      <section className="w-full pb-16 md:pb-24" aria-label="How we work">
        <div className="mx-auto max-w-site px-5 sm:px-8">
          <ul className="grid gap-4 md:grid-cols-2">
            {promises.map((p, i) =>
            <li key={p}>
                <Reveal delay={i * 0.05} className="h-full">
                  <div className="h-full rounded-feature border border-ink/10 bg-white p-7">
                    <span className="label text-atlas">{String(i + 1).padStart(2, '0')}</span>
                    <p className="mt-4 text-bodylg text-ink">{p}</p>
                  </div>
                </Reveal>
              </li>
            )}
          </ul>
        </div>
      </section>

      <Method />
      <AIAndHuman />
      <Beliefs />

      <section className="w-full bg-base py-16 md:py-24">
        <div className="mx-auto flex max-w-site flex-wrap items-center gap-6 px-5 sm:px-8">
          <p className="flex-1 text-h3 font-semibold">
            The process is the reason the work is fast.
          </p>
          <CTAButton to="/contact" size="lg">
            Book a Call
          </CTAButton>
        </div>
      </section>
    </>);

}