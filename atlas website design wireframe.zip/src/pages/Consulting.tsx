import React from 'react';
import { PageHeader } from '../components/PageHeader';
import { Consultancy } from '../components/home/Consultancy';
import { CTAButton } from '../components/ui/CTAButton';
import { Reveal } from '../components/ui/Reveal';
import { usePageMeta } from '../hooks/usePageMeta';

const decisions = [
{ verdict: 'Build', when: 'The opportunity is clear, valuable and nothing off the shelf fits it.' },
{ verdict: 'Integrate', when: 'The capability exists; the business just cannot reach it from where it is.' },
{ verdict: 'Automate', when: 'The process is correct but a person is doing the machine\u2019s share of it.' },
{ verdict: 'Redesign', when: 'The system works but people avoid it, so the data is unreliable.' },
{ verdict: 'Don\u2019t build', when: 'The cost is real, the payoff is speculative, and a process change would do.' }];


export function Consulting() {
  usePageMeta({
    title: 'Consultancy — Atlas Intelligence Group',
    description:
    'Understand, diagnose, prioritize, decide, execute. Working out where AI or software actually helps a business before anything gets built.',
    path: '/consulting'
  });

  return (
    <>
      <PageHeader
        label="Consultancy"
        title="Decide before you build."
        lede="Slow, quiet, unglamorous work that saves businesses from expensive software they did not need."
        accent="#7C3AED" />
      

      <Consultancy />

      <section className="w-full bg-base py-16 md:py-24" aria-labelledby="decisions-title">
        <div className="mx-auto max-w-site px-5 sm:px-8">
          <h2 id="decisions-title" className="max-w-2xl text-h2 font-semibold">
            Five honest endings to a discovery conversation.
          </h2>
          <ul className="mt-10 divide-y divide-ink/10 border-y border-ink/10">
            {decisions.map((d, i) =>
            <li key={d.verdict}>
                <Reveal delay={i * 0.04}>
                  <div className="grid gap-2 py-6 md:grid-cols-[220px_1fr] md:gap-10">
                    <h3 className="text-h4 font-semibold text-ink">{d.verdict}</h3>
                    <p className="text-bodylg text-ink-muted">{d.when}</p>
                  </div>
                </Reveal>
              </li>
            )}
          </ul>

          <div className="mt-12 flex flex-wrap items-center gap-4 rounded-feature border border-ink/10 bg-white p-8">
            <p className="flex-1 text-bodylg text-ink">
              A consultancy engagement ends with a decision and a sequence — not a deck.
            </p>
            <CTAButton to="/contact">Book a Call</CTAButton>
          </div>
        </div>
      </section>
    </>);

}