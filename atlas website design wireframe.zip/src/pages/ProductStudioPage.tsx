import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { studioProducts } from '../data/studio';
import { PageHeader } from '../components/PageHeader';
import { CTAButton } from '../components/ui/CTAButton';
import { usePageMeta } from '../hooks/usePageMeta';

const statuses = ['All', 'Research', 'Prototype', 'Building', 'Private beta', 'Live'] as const;

export function ProductStudioPage() {
  const [filter, setFilter] = useState<(typeof statuses)[number]>('All');
  const visible = studioProducts.filter((p) => filter === 'All' || p.status === filter);

  usePageMeta({
    title: 'Product Studio — Atlas Intelligence Group',
    description:
    'AIG\'s own IP: AI-driven software for underserved and emerging markets, internal R&D, and platform infrastructure other products build on.',
    path: '/product-studio'
  });

  return (
    <>
      <PageHeader
        label="Product Studio"
        title={
        <>
            We build what should exist.
            <span className="block text-white/45">Then we tell you exactly how far along it is.</span>
          </>
        }
        lede="AIG's second arm: our own products, our own research, and the platform infrastructure underneath them."
        tone="dark"
        accent="#B7FF3C"
        gradient="linear-gradient(150deg, #7C3AED 0%, #08090B 50%, #FF3CAC 120%)" />
      

      <section className="w-full py-16 md:py-24" aria-label="Studio products">
        <div className="mx-auto max-w-site px-5 sm:px-8">
          <div className="flex flex-wrap gap-2" role="group" aria-label="Filter by status">
            {statuses.map((s) =>
            <button
              key={s}
              type="button"
              onClick={() => setFilter(s)}
              aria-pressed={filter === s}
              className={`rounded-control border px-3.5 py-2 text-[13px] transition-colors ${
              filter === s ?
              'border-ink bg-ink text-white' :
              'border-ink/12 bg-white text-ink-muted hover:border-ink/40 hover:text-ink'}`
              }>
              
                {s}
              </button>
            )}
          </div>

          {visible.length === 0 ?
          <p className="mt-12 rounded-feature border border-dashed border-ink/20 bg-white p-10 text-center text-sm text-ink-muted">
              Nothing at this stage yet. When something reaches it, it will appear here.
            </p> :

          <ul className="mt-10 grid gap-4 lg:grid-cols-2">
              {visible.map((p, i) =>
            <motion.li
              key={p.name}
              layout
              initial={{ opacity: 0, y: 18 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.45, delay: i * 0.05, ease: [0.22, 1, 0.36, 1] }}
              className="overflow-hidden rounded-feature border border-ink/10 bg-white">
              
                  <div
                className="flex items-center justify-between px-7 py-5"
                style={{ background: `linear-gradient(120deg, ${p.accent}33 0%, transparent 80%)` }}>
                
                    <h2 className="text-h3 font-semibold">{p.name}</h2>
                    <span
                  className="rounded-full px-2.5 py-1 text-[11px] font-medium"
                  style={{ background: p.accent, color: '#08090B' }}>
                  
                      {p.status}
                    </span>
                  </div>
                  <dl className="space-y-4 p-7">
                    {[
                ['Problem', p.problem],
                ['Market', p.market],
                ['Product', p.product],
                ['Technology', p.technology],
                ['What we\u2019re learning', p.learning]].
                map(([term, desc]) =>
                <div key={term} className="grid gap-1 sm:grid-cols-[130px_1fr] sm:gap-4">
                        <dt className="label pt-0.5 text-ink-faint">{term}</dt>
                        <dd className="text-[13px] leading-relaxed text-ink-muted">{desc}</dd>
                      </div>
                )}
                  </dl>
                </motion.li>
            )}
            </ul>
          }

          <div className="mt-12 rounded-feature border border-ink/10 bg-ink p-8 text-white sm:p-12">
            <h2 className="max-w-xl text-h2 font-semibold">
              Same discipline, different risk. The studio is where we learn things clients later benefit from.
            </h2>
            <div className="mt-8">
              <CTAButton to="/contact" variant="onDark">
                Book a Call
              </CTAButton>
            </div>
          </div>
        </div>
      </section>
    </>);

}