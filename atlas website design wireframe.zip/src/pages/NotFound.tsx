import React from 'react';
import { CTAButton } from '../components/ui/CTAButton';
import { usePageMeta } from '../hooks/usePageMeta';

export function NotFound() {
  usePageMeta({
    title: 'Page not found — Atlas Intelligence Group',
    description: 'The page you were looking for does not exist.',
    path: '/404'
  });

  return (
    <section className="mx-auto flex min-h-[60vh] max-w-site flex-col items-start justify-center px-5 py-24 sm:px-8">
      <span className="label text-ink-faint">404</span>
      <h1 className="mt-6 max-w-xl text-h1 font-semibold">This page doesn&rsquo;t exist yet.</h1>
      <p className="mt-5 max-w-md text-bodylg text-ink-muted">
        Rather than fake it, we&rsquo;ll point you somewhere real.
      </p>
      <div className="mt-9 flex flex-wrap gap-3">
        <CTAButton to="/">Back to the homepage</CTAButton>
        <CTAButton to="/contact" variant="secondary">
          Book a Call
        </CTAButton>
      </div>
    </section>);

}