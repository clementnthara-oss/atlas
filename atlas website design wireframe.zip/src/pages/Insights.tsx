import React from 'react';
import { motion } from 'framer-motion';
import { insights } from '../data/site';
import { PageHeader } from '../components/PageHeader';
import { CTAButton } from '../components/ui/CTAButton';
import { usePageMeta } from '../hooks/usePageMeta';

export function Insights() {
  usePageMeta({
    title: 'Insights — Atlas Intelligence Group',
    description:
    'Short, practical notes on AI systems, automation, brand and knowing when not to build. Written from the work, not from a content calendar.',
    path: '/insights'
  });

  return (
    <>
      <PageHeader
        label="Insights"
        title="Notes from the work."
        lede="Short, specific, and written only when we have something worth saying."
        accent="#25D9FF" />
      

      <section className="w-full pb-20 md:pb-30" aria-label="Articles">
        <div className="mx-auto max-w-site px-5 sm:px-8">
          <ul className="divide-y divide-ink/10 border-y border-ink/10">
            {insights.map((post, i) =>
            <motion.li
              key={post.slug}
              initial={{ opacity: 0, y: 16 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: '-40px' }}
              transition={{ duration: 0.45, delay: i * 0.05, ease: [0.22, 1, 0.36, 1] }}>
              
                <article className="grid gap-4 py-9 md:grid-cols-[180px_1fr] md:gap-10">
                  <div>
                    <span className="label" style={{ color: post.accent }}>
                      {post.kicker}
                    </span>
                    <p className="mt-2 text-[11px] text-ink-faint">{post.status}</p>
                  </div>
                  <div>
                    <h2 className="text-h3 font-semibold tracking-tight">{post.title}</h2>
                    <p className="mt-4 max-w-2xl text-bodylg text-ink-muted">{post.body}</p>
                  </div>
                </article>
              </motion.li>
            )}
          </ul>

          <div className="mt-12 rounded-feature border border-dashed border-ink/20 bg-white p-8 text-center">
            <h2 className="text-h4 font-semibold">More coming as the work produces it.</h2>
            <p className="mx-auto mt-3 max-w-lg text-sm text-ink-muted">
              We publish when a project teaches us something specific — not on a schedule.
            </p>
            <div className="mt-7 flex justify-center">
              <CTAButton to="/contact">Book a Call</CTAButton>
            </div>
          </div>
        </div>
      </section>
    </>);

}