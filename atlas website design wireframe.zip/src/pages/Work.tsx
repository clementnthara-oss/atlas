import React from 'react';
import { caseStudies } from '../data/caseStudies';
import { CaseStudyCard } from '../components/CaseStudyCard';
import { PageHeader } from '../components/PageHeader';
import { CTAButton } from '../components/ui/CTAButton';
import { usePageMeta } from '../hooks/usePageMeta';

const anatomy = [
'Client',
'The problem',
'The opportunity',
'The approach',
'What we built',
'The result',
'The evidence'];


export function Work() {
  usePageMeta({
    title: 'Work — Atlas Intelligence Group',
    description:
    'Documented engagement patterns from AIG: the problem, the discovery, the approach, what gets built, and what gets measured. No fabricated clients or results.',
    path: '/work'
  });

  return (
    <>
      <PageHeader
        label="Selected work"
        title="Evidence, not adjectives."
        lede="Every piece of work here is documented the same way: what was wrong, what we learned, what we decided, what we built, and what can be measured about it." />
      

      <section className="w-full pb-20 md:pb-30" aria-label="Case studies">
        <div className="mx-auto max-w-site px-5 sm:px-8">
          <div className="grid gap-4 rounded-feature border border-ink/10 bg-white p-6 sm:p-8 md:grid-cols-[1fr_1.4fr] md:gap-10">
            <div>
              <span className="label text-ink-faint">Anatomy of an AIG case study</span>
              <p className="mt-4 text-[13px] leading-relaxed text-ink-muted">
                Client work is published only with permission and with sourced numbers attached. Until a
                figure is verified it reads &ldquo;not yet measured&rdquo; — including here.
              </p>
            </div>
            <ol className="flex flex-wrap gap-2 self-center">
              {anatomy.map((a, i) =>
              <li
                key={a}
                className="rounded-control border border-ink/12 bg-base px-3 py-2 text-[12px] text-ink-muted">
                
                  <span className="mr-2 text-ink-faint">{String(i + 1).padStart(2, '0')}</span>
                  {a}
                </li>
              )}
            </ol>
          </div>

          <div className="mt-8 space-y-4">
            {caseStudies.map((study, i) =>
            <CaseStudyCard key={study.slug} study={study} index={i} />
            )}
          </div>

          <div className="mt-8 rounded-feature border border-dashed border-ink/20 bg-base p-8 text-center">
            <h2 className="text-h3 font-semibold">Client case studies — coming soon</h2>
            <p className="mx-auto mt-3 max-w-xl text-sm text-ink-muted">
              Live engagements are in progress. They will be published when the client agrees and the outcome
              has been measured, and not a day before.
            </p>
            <div className="mt-7 flex flex-wrap justify-center gap-3">
              <CTAButton to="/contact">Book a Call</CTAButton>
              <CTAButton to="/approach" variant="secondary">
                See how we work
              </CTAButton>
            </div>
          </div>
        </div>
      </section>
    </>);

}