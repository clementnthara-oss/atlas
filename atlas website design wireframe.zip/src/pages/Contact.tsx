import React from 'react';
import { ContactForm } from '../components/ContactForm';
import { usePageMeta } from '../hooks/usePageMeta';

const expectations = [
{ title: 'A conversation, not a pitch', body: 'The first call is discovery. We are working out whether there is a real problem worth solving.' },
{ title: 'Direct founder access', body: 'You speak with the person who will design and build it.' },
{ title: 'An honest answer', body: 'If software is not the right answer, we will tell you that instead of quoting for it.' }];


export function Contact() {
  usePageMeta({
    title: 'Book a Call — Atlas Intelligence Group',
    description:
    'Tell us what you are trying to change. A short, specific brief gets a direct reply from the person who would build it.',
    path: '/contact'
  });

  return (
    <div className="w-full bg-base">
      <div className="mx-auto grid max-w-site gap-12 px-5 py-16 sm:px-8 md:py-24 lg:grid-cols-[1fr_1.35fr] lg:gap-20">
        <aside className="lg:sticky lg:top-24 lg:self-start">
          <span className="label text-ink-faint">Book a call</span>
          <h1 className="mt-5 text-h1 font-semibold">Tell us what you&rsquo;re trying to change.</h1>
          <p className="mt-5 text-bodylg text-ink-muted">
            Not what you want built — what you want different. The build follows from that.
          </p>

          <ul className="mt-10 space-y-6 border-t border-ink/10 pt-8">
            {expectations.map((e, i) =>
            <li key={e.title}>
                <span className="label text-atlas">{String(i + 1).padStart(2, '0')}</span>
                <h2 className="mt-2 text-h4 font-semibold">{e.title}</h2>
                <p className="mt-1.5 text-[13px] leading-relaxed text-ink-muted">{e.body}</p>
              </li>
            )}
          </ul>
        </aside>

        <div className="rounded-feature border border-ink/10 bg-white p-6 sm:p-10">
          <ContactForm />
        </div>
      </div>
    </div>);

}