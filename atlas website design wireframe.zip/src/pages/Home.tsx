import React, { useEffect } from 'react';
import { Hero } from '../components/home/Hero';
import { Outcomes } from '../components/home/Outcomes';
import { ServiceEcosystem } from '../components/home/ServiceEcosystem';
import { DigitalProducts } from '../components/home/DigitalProducts';
import { AIWorkflow } from '../components/home/AIWorkflow';
import { SystemMap } from '../components/home/SystemMap';
import { Automation } from '../components/home/Automation';
import { BrandTrust } from '../components/home/BrandTrust';
import { Consultancy } from '../components/home/Consultancy';
import { Method } from '../components/home/Method';
import { SelectedWork } from '../components/home/SelectedWork';
import { BehindTheBuild } from '../components/home/BehindTheBuild';
import { AIAndHuman } from '../components/home/AIAndHuman';
import { ProductStudio } from '../components/home/ProductStudio';
import { Beliefs } from '../components/home/Beliefs';
import { ImpactLedger } from '../components/home/ImpactLedger';
import { Founder } from '../components/home/Founder';
import { FinalCTA } from '../components/home/FinalCTA';
import { usePageMeta } from '../hooks/usePageMeta';

export function Home() {
  usePageMeta({
    title: 'Atlas Intelligence Group — AI agency for websites, AI agents, automation and business systems',
    description:
    'AIG is an AI agency with global reach. We understand the business, find what matters, and build what changes it: websites, SaaS, AI agents, CRMs, automation, brand and consultancy.',
    path: '/'
  });

  useEffect(() => {
    // Scroll-depth engagement signal (analytics layer hook point).
    const marks = [25, 50, 75, 100];
    const seen = new Set<number>();
    const onScroll = () => {
      const pct =
      window.scrollY / Math.max(1, document.body.scrollHeight - window.innerHeight) * 100;
      marks.forEach((m) => {
        if (pct >= m && !seen.has(m)) {
          seen.add(m);
          window.dispatchEvent(new CustomEvent('aig:scroll-depth', { detail: { depth: m, path: '/' } }));
        }
      });
    };
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  return (
    <>
      <Hero />
      <Outcomes />
      <ServiceEcosystem />
      <DigitalProducts />
      <AIWorkflow />
      <SystemMap />
      <Automation />
      <BrandTrust />
      <Consultancy />
      <Method />
      <SelectedWork />
      <BehindTheBuild />
      <AIAndHuman />
      <ProductStudio />
      <Beliefs />
      <ImpactLedger />
      <Founder />
      <FinalCTA />
    </>);

}