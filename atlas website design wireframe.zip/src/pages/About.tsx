import React from 'react';
import { PageHeader } from '../components/PageHeader';
import { Founder } from '../components/home/Founder';
import { Reveal } from '../components/ui/Reveal';
import { images } from '../data/site';
import { usePageMeta } from '../hooks/usePageMeta';

const arms = [
{
  name: 'Client Services',
  accent: '#2457FF',
  body: 'Client-facing, revenue-generating work: websites and web apps, SaaS, AI agents, CRMs and business systems, automation, AI integration, brand and consultancy.',
  items: ['Websites & web apps', 'SaaS development', 'AI agents', 'CRMs & business systems', 'Process automation', 'AI integration', 'Branding & identity', 'Consultancy']
},
{
  name: 'Product Studio',
  accent: '#FF3CAC',
  body: 'AIG\u2019s own IP: AI-driven software for underserved and emerging markets, internal R&D, and platform infrastructure other products can build on.',
  items: ['Own products', 'Internal R&D', 'Platform infrastructure']
}];


export function About() {
  usePageMeta({
    title: 'About — Atlas Intelligence Group',
    description:
    'AIG is an AI agency with global reach, built to expand. Two arms: client services and a product studio. We sell outcomes, not deliverables.',
    path: '/about'
  });

  return (
    <>
      <PageHeader
        label="About"
        title="An AI agency defined by what it changes, not where it sits."
        lede="AIG operates with global reach and is built to expand. It is not a static, one-service shop — capability gets added as client needs demand it." />
      

      <section className="w-full pb-16 md:pb-24" aria-label="How AIG is structured">
        <div className="mx-auto max-w-site px-5 sm:px-8">
          <div className="grid gap-4 lg:grid-cols-2">
            {arms.map((arm, i) =>
            <Reveal key={arm.name} delay={i * 0.06}>
                <article className="h-full overflow-hidden rounded-feature border border-ink/10 bg-white">
                  <div className="h-1.5 w-full" style={{ background: arm.accent }} aria-hidden="true" />
                  <div className="p-7 sm:p-9">
                    <h2 className="text-h2 font-semibold">{arm.name}</h2>
                    <p className="mt-4 text-bodylg text-ink-muted">{arm.body}</p>
                    <ul className="mt-7 flex flex-wrap gap-2">
                      {arm.items.map((it) =>
                    <li
                      key={it}
                      className="rounded-full border border-ink/12 px-3 py-1.5 text-[12px] text-ink-muted">
                      
                          {it}
                        </li>
                    )}
                    </ul>
                  </div>
                </article>
              </Reveal>
            )}
          </div>

          <div className="mt-16 grid gap-10 lg:grid-cols-[1.1fr_1fr] lg:items-center">
            <Reveal>
              <h2 className="text-h1 font-semibold">
                We don&rsquo;t sell deliverables. We sell what happens afterwards.
              </h2>
              <div className="mt-8 space-y-6">
                {[
                ['More revenue', 'New revenue streams, new clients, new ways of making money, stronger profits.'],
                ['Better-run operations', 'Less manual work, faster processes, fewer things falling through the cracks.'],
                ['Trust and credibility', 'A brand that looks and feels worth taking seriously — and worth paying for.'],
                ['Growth as a relationship', 'A long-term partner in the business\u2019s growth, not a vendor that vanishes after the invoice.']].
                map(([title, body], i) =>
                <div key={title} className="border-l-2 pl-5" style={{ borderColor: ['#2457FF', '#B7FF3C', '#FF3CAC', '#FF8A3D'][i] }}>
                    <h3 className="text-h4 font-semibold">{title}</h3>
                    <p className="mt-1.5 text-[14px] leading-relaxed text-ink-muted">{body}</p>
                  </div>
                )}
              </div>
            </Reveal>

            <Reveal delay={0.08}>
              <figure className="overflow-hidden rounded-feature border border-ink/10">
                <img
                  src={images.hands}
                  alt="Hands holding a tablet displaying a workflow diagram of connected nodes on a warm desk in natural light."
                  loading="lazy"
                  className="aspect-[3/2] w-full object-cover" />
                
                <figcaption className="bg-white px-5 py-3.5 text-[12px] text-ink-muted">
                  Work in progress, photographed as it happens.
                </figcaption>
              </figure>
            </Reveal>
          </div>
        </div>
      </section>

      <Founder />
    </>);

}