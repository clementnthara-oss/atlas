import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowUpRightIcon } from 'lucide-react';
import { services } from '../data/services';
import { outcomes } from '../data/outcomes';
import { PageHeader } from '../components/PageHeader';
import { FlowStrip } from '../components/system/FlowStrip';
import { CTAButton } from '../components/ui/CTAButton';
import { Reveal } from '../components/ui/Reveal';
import { usePageMeta } from '../hooks/usePageMeta';

export function ServicesOverview() {
  usePageMeta({
    title: 'Services — Atlas Intelligence Group',
    description:
    'Digital products, AI systems, business systems, automation, brand and consultancy. Two arms: client services and an in-house product studio.',
    path: '/services'
  });

  return (
    <>
      <PageHeader
        label="Services"
        title="Six capabilities, one operating system for the business."
        lede="We don't sell deliverables. A website, a CRM or an agent is how we help — never the point in itself."
        tone="dark"
        accent="#B7FF3C"
        gradient="radial-gradient(80% 70% at 15% 0%, rgba(36,87,255,0.35) 0%, transparent 60%), radial-gradient(60% 60% at 90% 100%, rgba(183,255,60,0.2) 0%, transparent 60%)" />
      

      <section className="w-full py-16 md:py-24" aria-label="Service list">
        <div className="mx-auto max-w-site px-5 sm:px-8">
          <ul className="space-y-4">
            {services.map((s, i) =>
            <li key={s.slug}>
                <Reveal delay={i * 0.04}>
                  <Link
                  to={`/services/${s.slug}`}
                  className="group grid gap-6 rounded-feature border border-ink/10 bg-white p-7 transition-colors duration-300 hover:border-ink/30 sm:p-9 lg:grid-cols-[1fr_1.1fr] lg:gap-12">
                  
                    <div>
                      <div className="flex items-center gap-3">
                        <span className="h-2 w-2 rounded-full" style={{ background: s.accent }} aria-hidden="true" />
                        <span className="label text-ink-faint">{String(i + 1).padStart(2, '0')}</span>
                      </div>
                      <h2 className="mt-4 flex items-center gap-2 text-h2 font-semibold">
                        {s.name}
                        <ArrowUpRightIcon
                        className="h-5 w-5 text-ink-faint transition-transform group-hover:translate-x-1 group-hover:-translate-y-1 group-hover:text-ink"
                        aria-hidden="true" />
                      
                      </h2>
                      <p className="mt-4 max-w-lg text-bodylg text-ink-muted">{s.description}</p>
                      <ul className="mt-6 flex flex-wrap gap-2">
                        {s.outcomes.map((o) => {
                        const outcome = outcomes.find((x) => x.key === o)!;
                        return (
                          <li
                            key={o}
                            className="rounded-full border px-2.5 py-1 text-[11px]"
                            style={{ borderColor: `${outcome.accent}66`, color: outcome.accent }}>
                            
                              {outcome.title}
                            </li>);

                      })}
                      </ul>
                    </div>

                    <div className="rounded-feature border border-ink/10 bg-base p-6">
                      <span className="label text-ink-faint">How it works</span>
                      <div className="mt-4">
                        <FlowStrip steps={s.flow} accent={s.accent} tone="light" />
                      </div>
                      <span className="mt-7 block label text-ink-faint">Capabilities</span>
                      <p className="mt-3 text-[13px] leading-relaxed text-ink-muted">
                        {s.capabilities.join(' · ')}
                      </p>
                    </div>
                  </Link>
                </Reveal>
              </li>
            )}
          </ul>

          <div className="mt-12 rounded-feature border border-ink/10 bg-ink p-8 text-white sm:p-12">
            <div className="flex flex-wrap items-end justify-between gap-6">
              <div>
                <h2 className="max-w-xl text-h2 font-semibold">
                  Not sure which of these you need? That is the consultancy conversation.
                </h2>
                <p className="mt-4 max-w-lg text-sm text-white/60">
                  We start every engagement by working out what the business is trying to accomplish. Sometimes
                  the answer is not to build anything.
                </p>
              </div>
              <div className="flex flex-wrap gap-3">
                <CTAButton to="/contact" variant="onDark">
                  Book a Call
                </CTAButton>
                <Link
                  to="/consulting"
                  className="inline-flex h-11 items-center rounded-control border border-white/30 px-5 text-sm text-white transition-colors hover:bg-white/10">
                  
                  Consultancy
                </Link>
              </div>
            </div>
          </div>
        </div>
      </section>
    </>);

}