import React, { useEffect } from 'react';
import { BrowserRouter, Route, Routes, useLocation } from 'react-router-dom';
import { Navbar } from './components/Navbar';
import { Footer } from './components/Footer';
import { Home } from './pages/Home';
import { Work } from './pages/Work';
import { CaseStudyPage } from './pages/CaseStudyPage';
import { ServicesOverview } from './pages/ServicesOverview';
import { ServiceDetail } from './pages/ServiceDetail';
import { Consulting } from './pages/Consulting';
import { ProductStudioPage } from './pages/ProductStudioPage';
import { Approach } from './pages/Approach';
import { About } from './pages/About';
import { Insights } from './pages/Insights';
import { Contact } from './pages/Contact';
import { NotFound } from './pages/NotFound';

function ScrollToTop() {
  const { pathname } = useLocation();
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'auto' });
  }, [pathname]);
  return null;
}

function StructuredData() {
  useEffect(() => {
    const script = document.createElement('script');
    script.type = 'application/ld+json';
    script.text = JSON.stringify({
      '@context': 'https://schema.org',
      '@type': 'ProfessionalService',
      name: 'Atlas Intelligence Group',
      alternateName: 'AIG',
      description:
      'An AI agency with global reach. Websites and web apps, SaaS, AI agents, CRMs and business systems, automation, brand and identity, and consultancy — plus an in-house product studio.',
      areaServed: 'Global',
      serviceType: [
      'Websites & web apps',
      'SaaS development',
      'AI agents',
      'CRMs and business systems',
      'Business process automation',
      'AI integration',
      'Branding & identity',
      'Consultancy'],

      url: window.location.origin
    });
    document.head.appendChild(script);
    return () => {
      document.head.removeChild(script);
    };
  }, []);
  return null;
}

export function App() {
  return (
    <BrowserRouter>
      <StructuredData />
      <ScrollToTop />
      <div className="flex min-h-screen w-full flex-col bg-base">
        <Navbar />
        <main id="main" className="flex-1 pt-16">
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/work" element={<Work />} />
            <Route path="/work/:slug" element={<CaseStudyPage />} />
            <Route path="/services" element={<ServicesOverview />} />
            <Route path="/services/:slug" element={<ServiceDetail />} />
            <Route path="/consulting" element={<Consulting />} />
            <Route path="/product-studio" element={<ProductStudioPage />} />
            <Route path="/approach" element={<Approach />} />
            <Route path="/about" element={<About />} />
            <Route path="/insights" element={<Insights />} />
            <Route path="/contact" element={<Contact />} />
            <Route path="*" element={<NotFound />} />
          </Routes>
        </main>
        <Footer />
      </div>
    </BrowserRouter>);

}