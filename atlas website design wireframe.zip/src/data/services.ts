import { Service } from '../types/content';

export const services: Service[] = [
{
  slug: 'digital-products',
  name: 'Digital Products',
  short: 'Websites, web apps and SaaS platforms.',
  description:
  'Websites, web applications and SaaS platforms designed around what a business needs people to do — not around what looks good in a template.',
  accent: '#2457FF',
  outcomes: ['revenue', 'trust'],
  capabilities: ['Marketing sites', 'Web applications', 'SaaS platforms', 'Customer portals', 'Dashboards', 'Design systems'],
  metricCategories: ['Conversion', 'Engagement', 'Task completion', 'Performance', 'Accessibility'],
  flow: ['Brand', 'Experience', 'Action', 'Result']
},
{
  slug: 'ai-systems',
  name: 'AI Systems',
  short: 'Agents that do real work inside the business.',
  description:
  'Customer service agents, workflow agents and internal tools that take an input, make a decision, take an action and leave a measurable trail behind them.',
  accent: '#B7FF3C',
  outcomes: ['efficiency', 'revenue'],
  capabilities: ['Customer service agents', 'Workflow agents', 'Internal tools', 'Retrieval over business data', 'Human-in-the-loop review', 'Evaluation and monitoring'],
  metricCategories: ['Resolution rate', 'Response time', 'Handoff quality', 'Coverage', 'Escalation rate'],
  flow: ['Enquiry', 'AI', 'Decision', 'Action', 'CRM', 'Result']
},
{
  slug: 'business-systems',
  name: 'Business Systems',
  short: 'CRMs and the connective tissue between them.',
  description:
  'CRMs, internal platforms and the integrations that hold a business together, so information moves without a person carrying it.',
  accent: '#25D9FF',
  outcomes: ['efficiency', 'growth'],
  capabilities: ['CRM design and build', 'Internal platforms', 'Integrations', 'Data models', 'Reporting', 'Role-based access'],
  metricCategories: ['Cycle time', 'Data completeness', 'Manual touchpoints', 'Adoption', 'Error rate'],
  flow: ['Lead', 'CRM', 'Operations', 'Analytics', 'Decision']
},
{
  slug: 'automation',
  name: 'Automation',
  short: 'Removing the work nobody should be doing.',
  description:
  'Business process automation and AI integration into existing workflows — starting with the steps that cost the most and add the least.',
  accent: '#FF8A3D',
  outcomes: ['efficiency', 'growth'],
  capabilities: ['Process mapping', 'Workflow automation', 'AI in existing tools', 'Document handling', 'Notifications and routing', 'Reporting automation'],
  metricCategories: ['Steps removed', 'Handling time', 'Throughput', 'Error rate', 'Backlog'],
  flow: ['Trigger', 'Understand', 'Qualify', 'Update', 'Respond', 'Report']
},
{
  slug: 'brand',
  name: 'Brand & Identity',
  short: 'Making a business look as capable as it is.',
  description:
  'Identity, design language and brand application, built so a customer trusts the business before they have spoken to anyone in it.',
  accent: '#FF3CAC',
  outcomes: ['trust', 'revenue'],
  capabilities: ['Identity systems', 'Typography and colour', 'Brand application', 'Design language', 'Messaging structure', 'Asset libraries'],
  metricCategories: ['Brand consistency', 'Perceived credibility', 'Recall', 'Conversion on first visit'],
  flow: ['Identity', 'Website', 'Product', 'Experience', 'Trust']
},
{
  slug: 'consultancy',
  name: 'Consultancy',
  short: 'Deciding what is worth building at all.',
  description:
  'Working out where AI or software actually helps — and where it does not — before anyone writes a line of code.',
  accent: '#7C3AED',
  outcomes: ['growth', 'efficiency'],
  capabilities: ['Discovery', 'Process diagnosis', 'Opportunity mapping', 'Technology selection', 'Roadmapping', 'Build / buy / do-nothing calls'],
  metricCategories: ['Opportunity value', 'Effort', 'Risk', 'Time to impact'],
  flow: ['Understand', 'Diagnose', 'Prioritize', 'Decide', 'Execute']
}];


export const getService = (slug: string) => services.find((s) => s.slug === slug);