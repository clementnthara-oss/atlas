import { CaseStudy } from '../types/content';

/**
 * AUTHENTICITY PROTOCOL
 * No client names, results or testimonials are invented here.
 * The entries below are explicitly labelled illustrative engagement patterns —
 * documented examples of how AIG works, not claimed client outcomes.
 * Every metric is unverified and rendered as "Not yet measured" until a real,
 * sourced number replaces it.
 */

const notMeasured = (name: string, unit: string | null = null) => ({
  name,
  before: null,
  after: null,
  change: null,
  unit,
  period: null,
  source: null,
  verified: false
});

export const caseStudies: CaseStudy[] = [
{
  slug: 'enquiry-to-booked-work',
  client: 'Illustrative engagement pattern',
  industry: 'Service business',
  status: 'Concept',
  published: true,
  accent: '#2457FF',
  summary:
  'What an enquiry-handling engagement looks like end to end, from first discovery call to a system that qualifies, records and follows up on its own.',
  problem:
  'Enquiries arrive across a form, an inbox and a phone. Someone reads each one, decides whether it is worth pursuing, writes a reply and — sometimes — remembers to follow up. The ones that fall through are invisible, so nobody knows what they cost.',
  opportunity:
  'The decision itself is not the hard part. The hard part is that it is made inconsistently, slowly, and without leaving a record. That is a systems problem, not a sales problem.',
  discovery:
  'Shadow the current process for a full cycle. Count the touchpoints. Find where enquiries stall and where information is re-typed. Establish what a good enquiry actually looks like, in the business owner\'s own words.',
  strategy:
  'Do not replace the human judgement at the point of sale. Replace the reading, sorting, recording and chasing that surrounds it.',
  design:
  'A single intake surface, one shared view of every live enquiry with its state visible, and a reply experience that feels like the business rather than like software.',
  engineering:
  'Structured data model first, then the intake, then the CRM writes, then the notification and follow-up layer. Deployed and tested before anyone is asked to change how they work.',
  ai: 'Intent understanding and qualification against criteria the business defined, with a confidence threshold that routes anything ambiguous to a person.',
  automation: 'Record creation, team notification, follow-up scheduling and weekly reporting.',
  outcome:
  'Every enquiry has a state, an owner and a next action. Nothing depends on someone remembering. The categories worth measuring are response time, qualification consistency, follow-up completion and enquiry-to-conversation rate.',
  reflection:
  'The first instinct is usually to automate the reply. The higher-value move is almost always to automate the record.',
  services: ['ai-systems', 'business-systems', 'automation'],
  technology: ['React', 'TypeScript', 'Structured LLM tooling', 'CRM integration', 'Event-driven jobs'],
  metrics: [
  notMeasured('First response time', 'minutes'),
  notMeasured('Qualification consistency', '%'),
  notMeasured('Follow-up completion', '%'),
  notMeasured('Enquiry → conversation', '%')]

},
{
  slug: 'credibility-rebuild',
  client: 'Illustrative engagement pattern',
  industry: 'Established business, dated presence',
  status: 'Concept',
  published: true,
  accent: '#FF3CAC',
  summary:
  'A business that is materially better than it looks. The work is identity and digital experience, and the outcome being bought is trust.',
  problem:
  'The capability is real; the presentation is a decade behind it. Customers arrive, hesitate, and compare the business against competitors who are worse but look better.',
  opportunity:
  'Nothing about the offer needs to change. The gap is entirely between what the business is and what a stranger can tell in eight seconds.',
  discovery:
  'Interview customers who bought and customers who did not. Audit every place the brand touches a person. Identify which specific moment creates the doubt.',
  strategy:
  'Rebuild credibility at the exact points of hesitation first — proof, clarity of offer, and the ease of starting a conversation — before touching anything decorative.',
  design:
  'An identity system with real rules, a design language that survives contact with real content, and a site built around the decision the visitor is actually making.',
  engineering:
  'Fast, accessible, semantic front end. Content modelled so the business can extend it without a designer.',
  ai: 'Used internally to accelerate research synthesis and content structuring. Not shipped as a customer-facing feature, because it would not have helped here.',
  automation: 'Enquiry routing and a simple content publishing workflow.',
  outcome:
  'The business becomes legible. Measurable categories: conversion on first visit, bounce on key pages, enquiry quality, and time to first contact.',
  reflection:
  'Brand work is often dismissed as cosmetic. It is usually the cheapest available lever on conversion.',
  services: ['brand', 'digital-products'],
  technology: ['React', 'TypeScript', 'Design tokens', 'Headless content model'],
  metrics: [
  notMeasured('Conversion on first visit', '%'),
  notMeasured('Enquiry quality', 'rating'),
  notMeasured('Time to first contact', 'hours'),
  notMeasured('Lighthouse performance', 'score')]

},
{
  slug: 'operations-connective-tissue',
  client: 'Illustrative engagement pattern',
  industry: 'Operations-heavy business',
  status: 'Concept',
  published: true,
  accent: '#25D9FF',
  summary:
  'Six tools, four spreadsheets and one person who understands how it all fits together. The engagement is about making the system survive that person taking a holiday.',
  problem:
  'Information moves between systems because a human carries it. Every handoff is a chance for the data to drift, and the true state of the business exists only in one head.',
  opportunity:
  'The tools are mostly fine. The connections between them do not exist.',
  discovery:
  'Map every system, every handoff and every spreadsheet. Mark each one as source of truth, copy, or fiction.',
  strategy:
  'Establish a single source of truth per entity, then connect outward. Do not migrate anything that does not need to move.',
  design:
  'One operational view that shows the real state of work, designed for the people who use it eight hours a day rather than for a demo.',
  engineering:
  'Integration layer, reconciliation jobs, audit trail, and role-based access. Rolled out one workflow at a time.',
  ai: 'Anomaly surfacing and summarisation over operational data, so exceptions come to people instead of people hunting for exceptions.',
  automation: 'Cross-system syncing, exception alerts and scheduled reporting.',
  outcome:
  'The business can see itself. Measurable categories: manual touchpoints per job, data completeness, cycle time and exception resolution time.',
  reflection:
  'Most "we need AI" conversations turn out, on inspection, to be "we need our systems to talk to each other" conversations.',
  services: ['business-systems', 'automation', 'consultancy'],
  technology: ['TypeScript', 'Integration APIs', 'Queue-based sync', 'Reporting layer'],
  metrics: [
  notMeasured('Manual touchpoints per job', 'count'),
  notMeasured('Data completeness', '%'),
  notMeasured('Cycle time', 'days'),
  notMeasured('Exception resolution time', 'hours')]

}];


export const getCaseStudy = (slug: string) => caseStudies.find((c) => c.slug === slug);