import { StudioProduct } from '../types/content';

/** AIG's own IP. Status is stated honestly — nothing here is presented as live. */
export const studioProducts: StudioProduct[] = [
{
  name: 'Atlas Ops',
  status: 'Prototype',
  problem:
  'Small operations teams run on spreadsheets because real operational software assumes a scale they do not have yet.',
  market: 'Owner-operated service businesses in emerging and underserved markets.',
  product: 'A lightweight operational layer: jobs, states, handoffs and exceptions, with AI surfacing what needs attention.',
  technology: 'TypeScript, event-sourced core, structured LLM tooling.',
  learning: 'The hardest part is not the software. It is designing for a business that changes its own process every month.',
  accent: '#B7FF3C'
},
{
  name: 'Signal',
  status: 'Research',
  problem:
  'Businesses collect enormous amounts of customer conversation and learn almost nothing from it.',
  market: 'Service and support-heavy businesses.',
  product: 'Continuous synthesis of customer conversations into decisions a person can act on this week.',
  technology: 'Retrieval, clustering, evaluation harness.',
  learning: 'Summaries are cheap. Deciding what deserves a human\'s attention is the actual product.',
  accent: '#25D9FF'
},
{
  name: 'Groundwork',
  status: 'Building',
  problem:
  'Every AI feature AIG builds re-solves the same problems: retrieval, evaluation, human review, audit trail.',
  market: 'Internal platform infrastructure — the base other AIG products build on.',
  product: 'A shared substrate for agent workflows with review and measurement built in from the start.',
  technology: 'TypeScript, workflow runtime, evaluation tooling.',
  learning: 'An agent without an evaluation loop is a demo, not a system.',
  accent: '#FF3CAC'
},
{
  name: 'Unnamed — market study',
  status: 'Research',
  problem: 'Under active investigation. Nothing is being claimed until there is something to claim.',
  market: 'Emerging markets, to be confirmed.',
  product: 'Coming soon.',
  technology: 'To be determined.',
  learning: 'Publishing a product page before a product exists is how credibility gets spent early.',
  accent: '#7C3AED'
}];