import { OutcomeKey } from '../types/content';

export interface Outcome {
  key: OutcomeKey;
  title: string;
  line: string;
  accent: string;
  ink: string;
  points: string[];
}

export const outcomes: Outcome[] = [
{
  key: 'revenue',
  title: 'Revenue',
  line: 'New customers, better conversion, new ways of making money.',
  accent: '#2457FF',
  ink: '#FFFFFF',
  points: ['More customers', 'Better conversion', 'New revenue streams', 'Stronger profitability', 'New monetization']
},
{
  key: 'efficiency',
  title: 'Efficiency',
  line: 'Less manual work, faster workflows, fewer things dropped.',
  accent: '#B7FF3C',
  ink: '#08090B',
  points: ['Less manual work', 'Faster workflows', 'Lower friction', 'Fewer errors', 'Better throughput']
},
{
  key: 'trust',
  title: 'Trust',
  line: 'A business that looks and feels worth paying for.',
  accent: '#FF3CAC',
  ink: '#FFFFFF',
  points: ['Stronger brand', 'Better customer experience', 'Professional presence', 'Greater credibility', 'Customer confidence']
},
{
  key: 'growth',
  title: 'Growth',
  line: 'Infrastructure that lets the business become something else.',
  accent: '#FF8A3D',
  ink: '#08090B',
  points: ['Better infrastructure', 'New capabilities', 'New markets', 'Product development', 'Long-term leverage']
}];