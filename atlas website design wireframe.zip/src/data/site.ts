export const images = {
  artifacts: "/34581353-4a63-46c5-88fd-f7fd06a46afe.jpg",
  screens: "/bb311840-d781-49c9-99cd-6312ac866c12.jpg",
  brand: "/946368d4-5d20-4d1f-913d-992d03540cb4.jpg",
  hands: "/f6e5541c-a6a5-419c-9a57-514a1738999a.jpg"
};

export const beliefs = [
{
  title: 'Outcomes over outputs.',
  body: 'A website isn\'t the goal. A website that creates value is.'
},
{
  title: 'Understand before building.',
  body: 'Technology isn\'t the first question. The business problem is.'
},
{
  title: 'Design and engineering belong together.',
  body: 'Beautiful software that doesn\'t work is failure. Functional software nobody wants is also failure.'
},
{
  title: 'Speed without shortcuts.',
  body: 'Fast because the process is disciplined. Not fast because corners were cut.'
},
{
  title: 'Say what\'s true.',
  body: 'No fake metrics. No inflated claims. No pretending prototypes are production.'
},
{
  title: 'Build relationships, not invoices.',
  body: 'Launch is the beginning of the next iteration.'
}];


export const method = [
{
  stage: 'Discover',
  question: 'What is the business actually trying to do?',
  inputs: ['Business goals', 'Current process', 'Customer reality', 'Constraints'],
  outputs: ['Problem definition', 'Opportunity map', 'Success criteria'],
  accent: '#2457FF'
},
{
  stage: 'Design',
  question: 'What should this be, exactly?',
  inputs: ['Problem definition', 'Brand', 'Content', 'Technical constraints'],
  outputs: ['Flows', 'Interface', 'Design system', 'Prototype'],
  accent: '#25D9FF'
},
{
  stage: 'Engineer',
  question: 'How is it built so it lasts?',
  inputs: ['Prototype', 'Data model', 'Integrations'],
  outputs: ['Working system', 'Documentation', 'Instrumentation'],
  accent: '#B7FF3C'
},
{
  stage: 'Test',
  question: 'Where does it break?',
  inputs: ['Working system', 'Real data', 'Real users'],
  outputs: ['Fixes', 'Evaluations', 'Confidence'],
  accent: '#FF8A3D'
},
{
  stage: 'Deploy',
  question: 'Is it stable on day one?',
  inputs: ['Tested system', 'Environments', 'Rollout plan'],
  outputs: ['Live system', 'Monitoring', 'Handover'],
  accent: '#FF3CAC'
},
{
  stage: 'Evolve',
  question: 'What did we learn, and what changes next?',
  inputs: ['Usage', 'Measurement', 'Business change'],
  outputs: ['Next iteration', 'New opportunities'],
  accent: '#7C3AED'
}];


export const ledger = [
{ name: 'Revenue influenced', note: 'Tracked per engagement', value: null },
{ name: 'Hours saved', note: 'Measured against baseline', value: null },
{ name: 'Processes automated', note: 'Counted at handover', value: null },
{ name: 'Systems deployed', note: 'Production only', value: null },
{ name: 'Businesses supported', note: 'Active partnerships', value: null },
{ name: 'Markets reached', note: 'Global by design', value: null }];


export const insights = [
{
  slug: 'automate-the-record',
  title: 'Automate the record, not the reply',
  kicker: 'Automation',
  body: 'The instinct is to have AI write the response. The durable value is almost always in having the system remember what happened, so nothing depends on a person\'s memory.',
  accent: '#FF8A3D',
  status: 'Published'
},
{
  slug: 'agents-need-evaluation',
  title: 'An agent without evaluation is a demo',
  kicker: 'AI Systems',
  body: 'If you cannot measure whether the agent made a good decision, you have not shipped a system — you have shipped a liability with good manners.',
  accent: '#B7FF3C',
  status: 'Published'
},
{
  slug: 'brand-is-a-conversion-lever',
  title: 'Brand is a conversion lever, not decoration',
  kicker: 'Brand & Trust',
  body: 'A business that looks less capable than it is pays for that gap on every single enquiry. It is usually the cheapest thing to fix.',
  accent: '#FF3CAC',
  status: 'Published'
},
{
  slug: 'when-not-to-build',
  title: 'The case for not building anything',
  kicker: 'Consultancy',
  body: 'Sometimes the honest recommendation is a process change and a spreadsheet. Saying so is how you earn the right to build the next thing.',
  accent: '#7C3AED',
  status: 'Published'
}];