export default {content: [
  './index.html',
  './src/**/*.{js,ts,jsx,tsx}'
],
  theme: {
    extend: {
      colors: {
        base: {
          DEFAULT: '#FAFAF7',
          white: '#FFFFFF',
          soft: '#F2F3F5',
          line: '#E5E4DF',
        },
        ink: {
          DEFAULT: '#08090B',
          soft: '#111318',
          muted: '#5A5D66',
          faint: '#8A8D96',
        },
        atlas: '#2457FF',
        electric: '#3B82FF',
        neon: '#B7FF3C',
        grass: '#61FF8E',
        magenta: '#FF3CAC',
        hotpink: '#FF4FD8',
        violet: '#7C3AED',
        cyan: '#25D9FF',
        orange: '#FF8A3D',
      },
      fontFamily: {
        sans: ['Inter', 'ui-sans-serif', 'system-ui', 'sans-serif'],
        mono: ['"JetBrains Mono"', 'ui-monospace', 'monospace'],
      },
      fontSize: {
        display: ['clamp(2.75rem, 7vw, 6rem)', { lineHeight: '0.95', letterSpacing: '-0.035em' }],
        h1: ['clamp(2.25rem, 5vw, 4rem)', { lineHeight: '1.02', letterSpacing: '-0.03em' }],
        h2: ['clamp(1.75rem, 3.4vw, 3rem)', { lineHeight: '1.06', letterSpacing: '-0.025em' }],
        h3: ['clamp(1.35rem, 2vw, 1.875rem)', { lineHeight: '1.15', letterSpacing: '-0.02em' }],
        h4: ['1.125rem', { lineHeight: '1.3', letterSpacing: '-0.01em' }],
        bodylg: ['1.125rem', { lineHeight: '1.6' }],
      },
      spacing: {
        13: '3.25rem',
        18: '4.5rem',
        30: '7.5rem',
        38: '9.5rem',
      },
      maxWidth: {
        site: '1360px',
      },
      borderRadius: {
        control: '8px',
        card: '16px',
        feature: '24px',
        hero: '32px',
      },
      transitionTimingFunction: {
        atlas: 'cubic-bezier(0.22, 1, 0.36, 1)',
      },
    },
  },
}
